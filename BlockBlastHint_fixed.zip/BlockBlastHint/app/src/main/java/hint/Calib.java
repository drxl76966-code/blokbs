package hint;

/**
 * Belajar offset drag. Di Block Blast blok yang diseret tampil DI ATAS jari (jaraknya tidak diketahui),
 * jadi titik lepas jari = pusat tujuan + offset (satuan "kotak", supaya tidak tergantung resolusi).
 *
 * Hasil drag cuma bisa diukur dalam bilangan bulat (blok mendarat meleset dr baris / dc kolom), karena
 * game membulatkan ke kotak terdekat. Satu pengamatan (offset dipakai u, meleset e) berarti offset yang
 * benar ada di rentang (u - e - 0.5, u - e + 0.5]. Rentang dari beberapa pengamatan dipotong-potong,
 * lalu offset dipakai di TENGAH rentang -> blok mendarat benar untuk semua nilai di dalam rentang.
 *
 * Offset Y dipisah per tinggi blok (kalau game mengangkat dari tepi bawah blok, bukan dari tengah, offset-nya
 * beda per tinggi). Tinggi yang belum pernah dilatih meminjam offset terakhir yang berhasil.
 */
public final class Calib {
    private static final float DEFAULT_Y = 1.5f;
    /** Kalau blok tidak menempel sama sekali, coba offset lain secara bergiliran. */
    private static final float[] PROBE = {0f, 1f, -1f, 2f, -2f, 3f, 4f, -3f};

    private final double[] yLo = new double[6], yHi = new double[6];   // indeks = tinggi blok 1..5
    private final boolean[] yHas = new boolean[6];
    private double xLo, xHi;
    private boolean xHas;
    private float lastY = DEFAULT_Y;

    private float usedX, usedY;
    private int usedH = 1, fails;

    private static int hi(int h) { return Math.max(1, Math.min(5, h)); }

    private float yCenter(int h) {
        h = hi(h);
        if (yHas[h]) return clamp((float) ((yLo[h] + yHi[h]) / 2), -3f, 7f);
        return predictY(h);
    }

    /** Tinggi yang belum pernah dilatih: kalau sudah ada >= 2 tinggi lain, tarik garis lurus; kalau tidak, pinjam yang terakhir. */
    private float predictY(int h) {
        int n = 0;
        double sh = 0, sc = 0, shh = 0, shc = 0;
        for (int k = 1; k <= 5; k++) {
            if (!yHas[k]) continue;
            double c = (yLo[k] + yHi[k]) / 2;
            n++; sh += k; sc += c; shh += (double) k * k; shc += k * c;
        }
        if (n < 2) return lastY;
        double den = n * shh - sh * sh;
        if (Math.abs(den) < 1e-9) return lastY;
        double b = (n * shc - sh * sc) / den, a = (sc - b * sh) / n;
        b = Math.max(-1.0, Math.min(1.0, b));   // kemiringan wajar saja
        a = (sc - b * sh) / n;
        return clamp((float) (a + b * h), -3f, 7f);
    }

    private float xCenter() { return xHas ? clamp((float) ((xLo + xHi) / 2), -3f, 3f) : 0f; }

    /** Offset {x, y} (satuan kotak) untuk drag berikutnya, untuk blok setinggi h kotak. */
    public float[] next(int h) {
        usedH = hi(h);
        usedX = xCenter();
        usedY = yCenter(usedH) + PROBE[Math.min(fails, PROBE.length - 1)];
        return new float[]{usedX, usedY};
    }

    public boolean exhausted() { return fails >= PROBE.length; }

    /** Blok mendarat meleset dr baris dan dc kolom dari tujuan (0,0 = tepat). */
    public void onLanded(int dr, int dc) {
        fails = 0;
        int h = usedH;
        double nlo = usedY - dr - 0.5, nhi = usedY - dr + 0.5;
        if (yHas[h]) {
            double l = Math.max(yLo[h], nlo), u = Math.min(yHi[h], nhi);
            if (l <= u) { yLo[h] = l; yHi[h] = u; } else { yLo[h] = nlo; yHi[h] = nhi; }   // tidak konsisten: percaya yang terbaru
        } else { yLo[h] = nlo; yHi[h] = nhi; yHas[h] = true; }
        lastY = yCenter(h);

        double xl = usedX - dc - 0.5, xh = usedX - dc + 0.5;
        if (xHas) {
            double l = Math.max(xLo, xl), u = Math.min(xHi, xh);
            if (l <= u) { xLo = l; xHi = u; } else { xLo = xl; xHi = xh; }
        } else { xLo = xl; xHi = xh; xHas = true; }
    }

    public void onFail() { fails++; }

    // ---- simpan / muat (untuk SharedPreferences) ----

    public String save() {
        StringBuilder sb = new StringBuilder();
        sb.append(xHas ? Float.toString(xCenter()) : "n").append('|');
        for (int h = 1; h <= 5; h++) {
            if (h > 1) sb.append(',');
            sb.append(yHas[h] ? Float.toString(yCenter(h)) : "n");
        }
        return sb.toString();
    }

    public static Calib load(String s) {
        Calib c = new Calib();
        if (s == null) return c;
        try {
            String[] top = s.split("\\|");
            if (top.length != 2) return c;
            if (!top[0].equals("n")) { double v = Double.parseDouble(top[0]); c.xLo = v - 0.5; c.xHi = v + 0.5; c.xHas = true; }
            String[] ys = top[1].split(",");
            for (int h = 1; h <= 5 && h - 1 < ys.length; h++) {
                if (ys[h - 1].equals("n")) continue;
                double v = Double.parseDouble(ys[h - 1]);
                c.yLo[h] = v - 0.5; c.yHi[h] = v + 0.5; c.yHas[h] = true;
                c.lastY = (float) v;
            }
        } catch (RuntimeException e) {
            return new Calib();
        }
        return c;
    }

    private static float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }
}
