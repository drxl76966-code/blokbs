package hint;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Mengurai jawaban teks Gemini (papan + 3 blok) menjadi struktur yang dipakai solver. Tanpa kelas Android. */
public final class GeminiParse {
    public static final class Reading {
        public final int[] board = new int[8];
        public final Piece[] pieces = new Piece[3];
        public String error;
    }

    private static final Pattern ROW = Pattern.compile("^[01]{8}$");
    private static final Pattern PIECE = Pattern.compile("^P([123])\\s*[:=]\\s*(.+)$", Pattern.CASE_INSENSITIVE);

    public static Reading parse(String text) {
        Reading out = new Reading();
        if (text == null) { out.error = "jawaban kosong"; return out; }
        int rows = 0;
        for (String raw : text.split("\\r?\\n")) {
            String line = raw.replace("`", "").replace("*", "").trim();
            if (line.isEmpty()) continue;
            String compact = line.replace(" ", "").replace(",", "");
            if (rows < 8 && ROW.matcher(compact).matches()) {
                int bits = 0;
                for (int c = 0; c < 8; c++) if (compact.charAt(c) == '1') bits |= 1 << c;
                out.board[rows++] = bits;
                continue;
            }
            Matcher m = PIECE.matcher(line);
            if (m.matches()) {
                int slot = m.group(1).charAt(0) - '1';
                out.pieces[slot] = shape(m.group(2));
            }
        }
        if (rows < 8) out.error = "papan tidak lengkap (" + rows + " dari 8 baris)";
        return out;
    }

    /** "XX/X." -> Piece. NONE / bentuk tak masuk akal -> null. Baris & kolom kosong di tepi dibuang. */
    static Piece shape(String s) {
        String t = s.replace("`", "").replace("*", "").replace(" ", "").toUpperCase();
        if (t.startsWith("NONE") || t.isEmpty()) return null;
        String[] parts = t.split("/");
        if (parts.length > 5) return null;
        int[] rows = new int[parts.length];
        int minR = parts.length, maxR = -1, minC = 99, maxC = -1;
        for (int i = 0; i < parts.length; i++) {
            if (parts[i].length() > 5) return null;
            for (int j = 0; j < parts[i].length(); j++) {
                if (parts[i].charAt(j) != 'X') continue;
                rows[i] |= 1 << j;
                minR = Math.min(minR, i); maxR = Math.max(maxR, i);
                minC = Math.min(minC, j); maxC = Math.max(maxC, j);
            }
        }
        if (maxR < 0) return null;
        int[] trimmed = new int[maxR - minR + 1];
        for (int i = minR; i <= maxR; i++) trimmed[i - minR] = rows[i] >> minC;
        return new Piece(trimmed, maxC - minC + 1);
    }
}
