package hint;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Membaca papan 8x8 dan 3 blok dari piksel screenshot (format 0xAARRGGBB).
 *
 * Tidak lagi bergantung pada warna tertentu (dulu: papan harus GELAP, tray harus "berwarna").
 * Sekarang:
 *  - papan dicari lewat perbedaan terhadap warna latar (per baris, jadi gradasi latar aman),
 *  - isi sel dibaca lewat efek bevel (sisi atas terang, sisi bawah gelap) yang cuma ada di blok,
 *  - blok di tray dicari lewat piksel "bukan latar, bukan bayangan, bukan abu-abu".
 */
public final class Detector {
    public static final class Slot {
        public Piece piece;          // null kalau slot kosong
        public float x, y, w, h;     // kotak blok di layar (px)
    }

    public static final class Result {
        public final int[] board = new int[8];
        public float left, top, cell; // pojok kiri-atas papan & ukuran satu kotak (px)
        public final Slot[] slots = new Slot[3];
        public String error;
    }

    private static final float TRAY_RATIO = 0.452f; // ukuran kotak blok di tray / kotak papan
    private static final String ERR_BOARD = "Papan tidak ketemu di layar";

    private static int r(int p) { return p >> 16 & 255; }
    private static int g(int p) { return p >> 8 & 255; }
    private static int b(int p) { return p & 255; }

    private static int diff(int p, int q) {
        return Math.abs(r(p) - r(q)) + Math.abs(g(p) - g(q)) + Math.abs(b(p) - b(q));
    }

    /** Warna latar di baris y: diambil dari tepi kiri layar (di luar papan). */
    private static int bgAt(int[] px, int w, int y) {
        return px[y * w + Math.max(2, (int) (w * 0.012f))];
    }

    /** Beda jelas dari latar? (dipakai untuk mencari papan) */
    private static boolean notBg(int p, int bg) { return diff(p, bg) >= 30; }

    /** Piksel milik blok (bukan latar, bukan bayangan, bukan abu-abu seperti toast/teks). */
    private static boolean blockPx(int p, int bg) {
        if (diff(p, bg) < 30) return false;
        int mx = Math.max(r(p), Math.max(g(p), b(p)));
        int mn = Math.min(r(p), Math.min(g(p), b(p)));
        if (mx - mn < 35) return false;                       // abu-abu / hitam / putih
        float fr = r(p) / (float) Math.max(1, r(bg));
        float fg = g(p) / (float) Math.max(1, g(bg));
        float fb = b(p) / (float) Math.max(1, b(bg));
        float hi = Math.max(fr, Math.max(fg, fb)), lo = Math.min(fr, Math.min(fg, fb));
        if (hi < 0.97f && hi - lo < 0.08f) return false;     // latar yang digelapkan rata = bayangan
        return true;
    }

    /** Run terpanjang dari flag true, boleh bolong sampai maxGap. Hasil {start,end} atau null. */
    private static int[] longestRun(boolean[] on, int from, int to, int maxGap) {
        int bs = -1, be = -1, s = -1, last = -1;
        for (int i = from; i <= to; i++) {
            if (on[i]) {
                if (s < 0) s = i;
                last = i;
            } else if (s >= 0 && i - last > maxGap) {
                if (bs < 0 || last - s > be - bs) { bs = s; be = last; }
                s = -1;
            }
        }
        if (s >= 0 && (bs < 0 || last - s > be - bs)) { bs = s; be = last; }
        return bs < 0 ? null : new int[]{bs, be};
    }

    private static int median(int[] a) {
        int[] c = a.clone();
        Arrays.sort(c);
        return c[c.length / 2];
    }

    /** Berapa piksel dari tepi bingkai sampai isi papan dimulai (0 kalau tidak ada bingkai). */
    private static int frameInset(int[] px, int w, int x0, int y0, int dx, int dy, int len, int maxIn) {
        int p0 = px[y0 * w + x0];
        int k = 0;
        while (k < maxIn) {
            int x = x0 + dx * k, y = y0 + dy * k;
            if (diff(px[y * w + x], p0) > 24) break;
            k++;
        }
        return k >= maxIn ? 0 : k + 2;   // +2 = titik awal scan sudah masuk 2px dari tepi
    }

    private static int avg(int[] px, int w, int h, int cx, int cy, int rx, int ry) {
        long rs = 0, gs = 0, bs = 0; int n = 0;
        for (int y = Math.max(0, cy - ry); y <= Math.min(h - 1, cy + ry); y++)
            for (int x = Math.max(0, cx - rx); x <= Math.min(w - 1, cx + rx); x++) {
                int p = px[y * w + x];
                rs += r(p); gs += g(p); bs += b(p); n++;
            }
        if (n == 0) return 0;
        return 0xFF000000 | (int) (rs / n) << 16 | (int) (gs / n) << 8 | (int) (bs / n);
    }

    public static Result detect(int[] px, int w, int h) {
        Result res = new Result();

        // ---- 1. kotak luar papan (termasuk bingkai) ----
        int y0 = (int) (h * 0.08), y1 = (int) (h * 0.90);
        boolean[] rowOn = new boolean[h];
        int needRow = (int) (w / 3 * 0.70);
        for (int y = y0; y < y1; y++) {
            int bg = bgAt(px, w, y), n = 0;
            for (int x = 0; x < w; x += 3) if (notBg(px[y * w + x], bg)) n++;
            rowOn[y] = n >= needRow;
        }
        int[] rr = longestRun(rowOn, y0, y1 - 1, 6);
        if (rr == null) { res.error = ERR_BOARD; return res; }
        int T = rr[0], B = rr[1];

        boolean[] colOn = new boolean[w];
        int needCol = (int) (((B - T) / 3) * 0.70);
        for (int x = 0; x < w; x++) {
            int n = 0;
            for (int y = T; y <= B; y += 3) if (notBg(px[y * w + x], bgAt(px, w, y))) n++;
            colOn[x] = n >= needCol;
        }
        int[] cr = longestRun(colOn, 0, w - 1, 6);
        if (cr == null) { res.error = ERR_BOARD; return res; }
        int L = cr[0], R = cr[1];

        int size = Math.max(R - L, B - T);
        if (size < w * 0.4f || Math.abs((R - L) - (B - T)) > 0.08f * size) { res.error = ERR_BOARD; return res; }

        // ---- 2. buang bingkai -> kotak grid 8x8 sebenarnya ----
        int maxIn = Math.max(6, (int) (size * 0.06f));
        int[] il = new int[8], ir = new int[8], it = new int[8], ib = new int[8];
        for (int k = 0; k < 8; k++) {
            int yy = T + (int) ((k + 0.5f) * (B - T + 1) / 8f);
            int xx = L + (int) ((k + 0.5f) * (R - L + 1) / 8f);
            il[k] = frameInset(px, w, L + 2, yy, 1, 0, size, maxIn);
            ir[k] = frameInset(px, w, R - 2, yy, -1, 0, size, maxIn);
            it[k] = frameInset(px, w, xx, T + 2, 0, 1, size, maxIn);
            ib[k] = frameInset(px, w, xx, B - 2, 0, -1, size, maxIn);
        }
        int gl = L + Math.max(0, median(il)), gr = R - Math.max(0, median(ir));
        int gt = T + Math.max(0, median(it)), gb = B - Math.max(0, median(ib));
        int bw = gr - gl + 1, bh = gb - gt + 1;
        if (Math.abs(bw - bh) > 0.06f * Math.max(bw, bh)) { res.error = ERR_BOARD; return res; }

        res.left = gl; res.top = gt;
        res.cell = (bw + bh) / 16f;

        // ---- 3. isi 64 sel ----
        int rad = Math.max(2, (int) (res.cell * 0.12f));
        int rx = Math.max(2, (int) (res.cell * 0.10f)), ry = Math.max(1, (int) (res.cell * 0.02f));
        int off = (int) (res.cell * 0.41f);
        int[] center = new int[64];
        boolean[] bevel = new boolean[64];
        for (int rI = 0; rI < 8; rI++)
            for (int c = 0; c < 8; c++) {
                int cx = (int) (gl + (c + 0.5f) * res.cell), cy = (int) (gt + (rI + 0.5f) * res.cell);
                int i = rI * 8 + c;
                center[i] = avg(px, w, h, cx, cy, rad, rad);
                int top = avg(px, w, h, cx, cy - off, rx, ry);
                int bot = avg(px, w, h, cx, cy + off, rx, ry);
                bevel[i] = diff(top, bot) > 60;       // sisi atas terang, bawah gelap = ada blok
            }
        // sel rata (kosong): warna tengahnya jadi acuan; sel rata yang warnanya beda jauh = blok polos
        int[] fr = new int[64], fg = new int[64], fb = new int[64];
        int nf = 0;
        for (int i = 0; i < 64; i++) if (!bevel[i]) { fr[nf] = r(center[i]); fg[nf] = g(center[i]); fb[nf] = b(center[i]); nf++; }
        int emptyRef = 0;
        if (nf > 0) {
            emptyRef = 0xFF000000 | median(Arrays.copyOf(fr, nf)) << 16 | median(Arrays.copyOf(fg, nf)) << 8 | median(Arrays.copyOf(fb, nf));
        }
        for (int i = 0; i < 64; i++) {
            boolean filled = bevel[i] || (nf > 0 && diff(center[i], emptyRef) > 70);
            if (filled) res.board[i / 8] |= 1 << (i % 8);
        }

        // ---- 4. blok di tray ----
        int ty0 = Math.min(h - 1, (int) (gb + res.cell * 0.4f));
        int ty1 = Math.min((int) (h * 0.95f), (int) (gb + res.cell * 4.2f));
        float ps = res.cell * TRAY_RATIO;

        int[] colCnt = new int[w];
        for (int y = ty0; y < ty1; y += 2) {
            int bg = bgAt(px, w, y);
            for (int x = 0; x < w; x++) if (blockPx(px[y * w + x], bg)) colCnt[x]++;
        }
        List<int[]> runs = new ArrayList<>();
        int s = -1, last = -1;
        int mergeGap = Math.max(2, (int) (ps * 0.6f));
        for (int x = 0; x < w; x++) {
            if (colCnt[x] >= 2) {
                if (s >= 0 && x - last > mergeGap) { runs.add(new int[]{s, last}); s = -1; }
                if (s < 0) s = x;
                last = x;
            }
        }
        if (s >= 0) runs.add(new int[]{s, last});
        for (int i = runs.size() - 1; i >= 0; i--)
            if (runs.get(i)[1] - runs.get(i)[0] + 1 < ps * 0.6f) runs.remove(i);
        while (runs.size() > 3) {                       // buang yang paling sempit
            int worst = 0;
            for (int i = 1; i < runs.size(); i++)
                if (runs.get(i)[1] - runs.get(i)[0] < runs.get(worst)[1] - runs.get(worst)[0]) worst = i;
            runs.remove(worst);
        }

        for (int i = 0; i < 3; i++) res.slots[i] = new Slot();
        int prevSlot = -1;
        for (int[] run : runs) {
            int minX = run[0], maxX = run[1];
            boolean[] yOn = new boolean[h];
            int need = Math.max(3, (int) ((maxX - minX) / 2 * 0.15f)); // baris harus cukup "penuh" blok
            for (int y = ty0; y < ty1; y++) {
                int bg = bgAt(px, w, y), n = 0;
                for (int x = minX; x <= maxX; x += 2) if (blockPx(px[y * w + x], bg)) n++;
                yOn[y] = n >= need;
            }
            // ambil gumpalan baris terpanjang -> garis nyasar (tepi toast, dll.) terpisah & diabaikan
            int[] yr = longestRun(yOn, ty0, ty1 - 1, Math.max(2, (int) (ps * 0.35f)));
            if (yr == null) continue;
            int minY = yr[0], maxY = yr[1];
            float sw = maxX - minX + 1, sh = maxY - minY + 1;
            int cols = Math.max(1, Math.min(5, Math.round(sw / ps)));
            int rows = Math.max(1, Math.min(5, Math.round(sh / ps)));
            float csx = sw / cols, csy = sh / rows;
            int[] pr = new int[rows];
            int pr2 = Math.max(1, (int) (Math.min(csx, csy) * 0.2f));
            for (int rI = 0; rI < rows; rI++)
                for (int c = 0; c < cols; c++) {
                    int cx = (int) (minX + (c + 0.5f) * csx), cy = (int) (minY + (rI + 0.5f) * csy);
                    int hit = 0, tot = 0;
                    for (int y = cy - pr2; y <= cy + pr2; y++) {
                        int bg = bgAt(px, w, y);
                        for (int x = cx - pr2; x <= cx + pr2; x++) { tot++; if (blockPx(px[y * w + x], bg)) hit++; }
                    }
                    if (hit * 2 >= tot) pr[rI] |= 1 << c;
                }
            int any = 0;
            for (int v : pr) any |= v;
            if (any == 0) continue;
            int slotIdx = Math.min(2, (int) (3f * (minX + maxX) / 2f / w));
            if (slotIdx <= prevSlot) slotIdx = Math.min(2, prevSlot + 1);
            prevSlot = slotIdx;
            Slot slot = res.slots[slotIdx];
            slot.piece = new Piece(pr, cols);
            slot.x = minX; slot.y = minY; slot.w = sw; slot.h = sh;
        }
        return res;
    }
}
