package hint;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Membaca papan 8x8 dan 3 blok dari piksel screenshot (format 0xAARRGGBB).
 *
 * Tidak lagi bergantung pada warna tertentu (dulu: papan harus GELAP, tray harus "berwarna").
 * Sekarang:
 *  - papan dicari lewat perbedaan terhadap warna latar (per baris, jadi gradasi latar aman),
 *  - isi sel dibaca lewat efek bevel (sisi atas terang, sisi bawah gelap) yang cuma ada di blok,
 *  - blok di tray dicari lewat piksel "bukan latar, bukan bayangan, bukan abu-abu".
 */
public final class Detector {
    public static final class Slot {
        public Piece piece;          // null kalau slot kosong
        public float x, y, w, h;     // kotak blok di layar (px)
    }

    public static final class Result {
        public final int[] board = new int[8];
        public float left, top, cell; // pojok kiri-atas papan & ukuran satu kotak (px)
        public float frame;           // tebal bingkai papan (px)
        public int hintCells;         // jumlah sel kotak-hint kita sendiri yang terdeteksi & diabaikan
        public final Slot[] slots = new Slot[3];
        public String error;

        /** Salinan yang cuma berisi posisi papan (untuk baca tray saja). */
        public Result geometryOnly() {
            Result g = new Result();
            g.left = left; g.top = top; g.cell = cell; g.frame = frame;
            return g;
        }
    }

    private static final float TRAY_RATIO = 0.452f; // ukuran kotak blok di tray / kotak papan
    private static final String ERR_BOARD = "Papan tidak ketemu di layar";

    private static int r(int p) { return p >> 16 & 255; }
    private static int g(int p) { return p >> 8 & 255; }
    private static int b(int p) { return p & 255; }

    private static int diff(int p, int q) {
        return Math.abs(r(p) - r(q)) + Math.abs(g(p) - g(q)) + Math.abs(b(p) - b(q));
    }

    /** Warna latar di baris y: diambil dari tepi kiri layar (di luar papan). */
    private static int bgAt(int[] px, int w, int y) {
        return px[y * w + Math.max(2, (int) (w * 0.012f))];
    }

    /** Beda jelas dari latar? (dipakai untuk mencari papan) */
    private static boolean notBg(int p, int bg) { return diff(p, bg) >= 30; }

    /** Piksel milik blok (bukan latar, bukan bayangan, bukan abu-abu seperti toast/teks). */
    private static boolean blockPx(int p, int bg) {
        if (diff(p, bg) < 30) return false;
        int mx = Math.max(r(p), Math.max(g(p), b(p)));
        int mn = Math.min(r(p), Math.min(g(p), b(p)));
        if (mx - mn < 26) return false;                       // abu-abu / hitam / putih (blok hijau zaitun ~32)
        float fr = r(p) / (float) Math.max(1, r(bg));
        float fg = g(p) / (float) Math.max(1, g(bg));
        float fb = b(p) / (float) Math.max(1, b(bg));
        float hi = Math.max(fr, Math.max(fg, fb)), lo = Math.min(fr, Math.min(fg, fb));
        if (hi < 0.97f && hi - lo < 0.08f) return false;     // latar yang digelapkan rata = bayangan
        return true;
    }

    /** Run terpanjang dari flag true, boleh bolong sampai maxGap. Hasil {start,end} atau null. */
    private static int[] longestRun(boolean[] on, int from, int to, int maxGap) {
        int bs = -1, be = -1, s = -1, last = -1;
        for (int i = from; i <= to; i++) {
            if (on[i]) {
                if (s < 0) s = i;
                last = i;
            } else if (s >= 0 && i - last > maxGap) {
                if (bs < 0 || last - s > be - bs) { bs = s; be = last; }
                s = -1;
            }
        }
        if (s >= 0 && (bs < 0 || last - s > be - bs)) { bs = s; be = last; }
        return bs < 0 ? null : new int[]{bs, be};
    }

    private static int median(int[] a) {
        int[] c = a.clone();
        Arrays.sort(c);
        return c[c.length / 2];
    }

    /** Berapa piksel dari tepi bingkai sampai isi papan dimulai (0 kalau tidak ada bingkai). */
    private static int frameInset(int[] px, int w, int x0, int y0, int dx, int dy, int len, int maxIn) {
        int p0 = px[y0 * w + x0];
        int k = 0;
        while (k < maxIn) {
            int x = x0 + dx * k, y = y0 + dy * k;
            if (diff(px[y * w + x], p0) > 24) break;
            k++;
        }
        return k >= maxIn ? 0 : k + 2;   // +2 = titik awal scan sudah masuk 2px dari tepi
    }

    private static int avg(int[] px, int w, int h, int cx, int cy, int rx, int ry) {
        long rs = 0, gs = 0, bs = 0; int n = 0;
        for (int y = Math.max(0, cy - ry); y <= Math.min(h - 1, cy + ry); y++)
            for (int x = Math.max(0, cx - rx); x <= Math.min(w - 1, cx + rx); x++) {
                int p = px[y * w + x];
                rs += r(p); gs += g(p); bs += b(p); n++;
            }
        if (n == 0) return 0;
        return 0xFF000000 | (int) (rs / n) << 16 | (int) (gs / n) << 8 | (int) (bs / n);
    }


    /**
     * Kekuatan garis pemisah sel sepanjang satu sumbu. vertical=true: garis tegak (posisi x = start + k*cell),
     * disampel di 8 baris (posisi y dari crossStart/crossCell). Hasil rata-rata 0..60, atau -1 kalau keluar layar.
     */
    private static float axisScore(int[] px, int w, int h, float start, float cell,
                                   float crossStart, float crossCell, boolean vertical) {
        float sum = 0;
        for (int k = 1; k < 8; k++) {
            for (int i = 0; i < 8; i++) {
                float along = start + k * cell, cross = crossStart + (i + 0.5f) * crossCell;
                float bx = vertical ? along : cross, by = vertical ? cross : along;
                float ax = vertical ? bx - cell * 0.5f : bx, ay = vertical ? by : by - cell * 0.5f;
                float cx = vertical ? bx + cell * 0.5f : bx, cy = vertical ? by : by + cell * 0.5f;
                int axi = (int) ax, ayi = (int) ay, cxi = (int) cx, cyi = (int) cy;
                if (axi < 0 || ayi < 0 || cxi >= w || cyi >= h || axi >= w || ayi >= h || cxi < 0 || cyi < 0) return -1f;
                int ca = px[ayi * w + axi], cb = px[cyi * w + cxi];
                int best = 0;
                for (int d = -2; d <= 2; d++) {
                    int x = (int) bx + (vertical ? d : 0), y = (int) by + (vertical ? 0 : d);
                    if (x < 0 || y < 0 || x >= w || y >= h) return -1f;
                    int p = px[y * w + x];
                    best = Math.max(best, Math.min(diff(p, ca), diff(p, cb)));
                }
                sum += Math.min(best, 60);
            }
        }
        return sum / 56f;
    }

    /**
     * Setel ulang left/top/cell supaya garis-garis pemisah sel pas dengan garis di layar. Perkiraan awal dari
     * tepi bingkai bisa meleset beberapa piksel (mis. bingkai dengan glow/gradasi), dan meleset segitu saja
     * sudah cukup bikin pembacaan sel & validasi grid gagal. Sumbu x dan y tidak saling bergantung,
     * jadi dicari terpisah. Ada penalti kecil untuk pergeseran supaya kalau seri, tetap pakai perkiraan awal.
     */
    private static void refineGrid(int[] px, int w, int h, Result g) {
        float c0 = g.cell;
        float left = g.left, top = g.top, cx = c0, cy = c0;
        for (int iter = 0; iter < 2; iter++) {
            float bestS = -1e9f, bl = left, bc = cx;
            for (float c = c0 * 0.92f; c <= c0 * 1.06f; c += 0.4f) {
                for (int dx = -18; dx <= 18; dx++) {
                    float l = left + dx;
                    float sc = axisScore(px, w, h, l, c, top, cy, true);
                    if (sc < 0) continue;
                    sc -= 0.03f * Math.abs(dx) + 0.03f * Math.abs(c - c0);
                    if (sc > bestS) { bestS = sc; bl = l; bc = c; }
                }
            }
            left = bl; cx = bc;

            bestS = -1e9f;
            float bt = top, bcy = cy;
            for (float c = c0 * 0.92f; c <= c0 * 1.06f; c += 0.4f) {
                for (int dy = -18; dy <= 18; dy++) {
                    float t = top + dy;
                    float sc = axisScore(px, w, h, t, c, left, cx, false);
                    if (sc < 0) continue;
                    sc -= 0.03f * Math.abs(dy) + 0.03f * Math.abs(c - c0);
                    if (sc > bestS) { bestS = sc; bt = t; bcy = c; }
                }
            }
            top = bt; cy = bcy;
        }
        // kotak harus (hampir) persegi; kalau hasilnya aneh, biarkan perkiraan awal & biar validasi yang menolak
        if (Math.abs(cx - cy) > 0.04f * c0) return;
        g.left = left; g.top = top; g.cell = (cx + cy) / 2f;
    }

    /**
     * Papan masih ada? Cek pola garis grid 8x8 (tidak peduli tema/warna/bingkai): di tiap garis
     * pemisah sel, warnanya harus beda jelas dari tengah sel. Wallpaper / layar lain tidak punya pola ini.
     * Hasil 0..1 (papan asli ~1.0). Aman dipanggil terus, juga saat kotak hint tampil di atas papan.
     */
    public static float gridScore(int[] px, int w, int h, Result g) {
        float cell = g.cell;
        int good = 0, total = 0;
        for (int k = 1; k < 8; k++)
            for (int i = 0; i < 8; i++) {
                for (int dir = 0; dir < 2; dir++) {
                    float bx = dir == 0 ? g.left + k * cell : g.left + (i + 0.5f) * cell;
                    float by = dir == 0 ? g.top + (i + 0.5f) * cell : g.top + k * cell;
                    float ax = dir == 0 ? bx - cell * 0.5f : bx, ay = dir == 0 ? by : by - cell * 0.5f; // tengah sel sebelum garis
                    float cx = dir == 0 ? bx + cell * 0.5f : bx, cy = dir == 0 ? by : by + cell * 0.5f; // tengah sel sesudah garis
                    int axi = (int) ax, ayi = (int) ay, cxi = (int) cx, cyi = (int) cy;
                    if (axi < 0 || ayi < 0 || cxi >= w || cyi >= h) return 0f;
                    int ca = px[ayi * w + axi], cb = px[cyi * w + cxi];
                    int best = 0;
                    for (int d = -2; d <= 2; d++) {
                        int x = (int) bx + (dir == 0 ? d : 0), y = (int) by + (dir == 0 ? 0 : d);
                        if (x < 0 || y < 0 || x >= w || y >= h) return 0f;
                        int p = px[y * w + x];
                        best = Math.max(best, Math.min(diff(p, ca), diff(p, cb))); // beda dari KEDUA sel di sisinya
                    }
                    total++;
                    if (best >= 22) good++;
                }
            }
        return total == 0 ? 0f : good / (float) total;
    }

    public static boolean gridOk(int[] px, int w, int h, Result g) {
        return gridScore(px, w, h, g) >= 0.8f;
    }

    /**
     * Kotak hint buatan app sendiri: sel dengan bingkai putih tipis (~4px) di keempat sisinya.
     * Sel begini cuma digambar di atas sel KOSONG, jadi kalau ikut tertangkap layar dianggap kosong,
     * supaya hint lama / frame basi tidak merusak bacaan papan.
     */
    private static boolean hintOverlayCell(int[] px, int w, int h, float cellLeft, float cellTop, float cell) {
        int sides = 0;
        for (int side = 0; side < 4; side++) {
            int ok = 0;
            for (int k = 0; k < 7; k++) {
                float t = 0.25f + k * 0.5f / 6f;
                boolean found = false;
                for (int d = 1; d <= 10 && !found; d++) {
                    float x, y;
                    if (side == 0) { x = cellLeft + t * cell; y = cellTop + d; }
                    else if (side == 1) { x = cellLeft + t * cell; y = cellTop + cell - 1 - d; }
                    else if (side == 2) { x = cellLeft + d; y = cellTop + t * cell; }
                    else { x = cellLeft + cell - 1 - d; y = cellTop + t * cell; }
                    int xi = (int) x, yi = (int) y;
                    if (xi < 0 || yi < 0 || xi >= w || yi >= h) continue;
                    int q = px[yi * w + xi];
                    int mn = Math.min(r(q), Math.min(g(q), b(q))), mx = Math.max(r(q), Math.max(g(q), b(q)));
                    if (mn >= 180 && mx - mn <= 30) found = true;   // putih / abu terang
                }
                if (found) ok++;
            }
            if (ok >= 5) sides++;
        }
        return sides == 4;
    }

    /** Baca 3 blok di tray memakai posisi papan yang sudah diketahui (res.left/top/cell). */
    public static void readTray(int[] px, int w, int h, Result res) {
        float gridBottom = res.top + 8 * res.cell;
        int ty0 = Math.min(h - 1, (int) (gridBottom + res.cell * 0.4f));
        int ty1 = Math.min((int) (h * 0.95f), (int) (gridBottom + res.cell * 3.4f));
        float ps = res.cell * TRAY_RATIO;

        int[] colCnt = new int[w];
        for (int y = ty0; y < ty1; y += 2) {
            int bg = bgAt(px, w, y);
            for (int x = 0; x < w; x++) if (blockPx(px[y * w + x], bg)) colCnt[x]++;
        }
        // Kolom blok asli punya >= ~ps/2 sampel; glow/garis tipis cuma 1-2. Syarat ini membuang glow di bawah papan.
        int minCol = Math.max(4, (int) (ps * 0.12f));
        List<int[]> runs = new ArrayList<>();
        int s = -1, last = -1;
        int mergeGap = Math.max(2, (int) (ps * 0.6f));
        for (int x = 0; x < w; x++) {
            if (colCnt[x] >= minCol) {
                if (s >= 0 && x - last > mergeGap) { runs.add(new int[]{s, last}); s = -1; }
                if (s < 0) s = x;
                last = x;
            }
        }
        if (s >= 0) runs.add(new int[]{s, last});
        for (int i = runs.size() - 1; i >= 0; i--)
            if (runs.get(i)[1] - runs.get(i)[0] + 1 < ps * 0.6f) runs.remove(i);
        while (runs.size() > 3) {                       // buang yang paling sempit
            int worst = 0;
            for (int i = 1; i < runs.size(); i++)
                if (runs.get(i)[1] - runs.get(i)[0] < runs.get(worst)[1] - runs.get(worst)[0]) worst = i;
            runs.remove(worst);
        }

        for (int i = 0; i < 3; i++) res.slots[i] = new Slot();
        int prevSlot = -1;
        for (int[] run : runs) {
            int minX = run[0], maxX = run[1];
            boolean[] yOn = new boolean[h];
            int need = Math.max(3, (int) ((maxX - minX) / 2 * 0.15f)); // baris harus cukup "penuh" blok
            for (int y = ty0; y < ty1; y++) {
                int bg = bgAt(px, w, y), n = 0;
                for (int x = minX; x <= maxX; x += 2) if (blockPx(px[y * w + x], bg)) n++;
                yOn[y] = n >= need;
            }
            // ambil gumpalan baris terpanjang -> garis nyasar (tepi toast, dll.) terpisah & diabaikan
            int[] yr = longestRun(yOn, ty0, ty1 - 1, Math.max(2, (int) (ps * 0.35f)));
            if (yr == null) continue;
            int minY = yr[0], maxY = yr[1];
            float sw = maxX - minX + 1, sh = maxY - minY + 1;
            int cols = Math.max(1, Math.min(5, Math.round(sw / ps)));
            int rows = Math.max(1, Math.min(5, Math.round(sh / ps)));
            float csx = sw / cols, csy = sh / rows;
            int[] pr = new int[rows];
            int pr2 = Math.max(1, (int) (Math.min(csx, csy) * 0.2f));
            for (int rI = 0; rI < rows; rI++)
                for (int c = 0; c < cols; c++) {
                    int cx = (int) (minX + (c + 0.5f) * csx), cy = (int) (minY + (rI + 0.5f) * csy);
                    int hit = 0, tot = 0;
                    for (int y = cy - pr2; y <= cy + pr2; y++) {
                        int bg = bgAt(px, w, y);
                        for (int x = cx - pr2; x <= cx + pr2; x++) { tot++; if (blockPx(px[y * w + x], bg)) hit++; }
                    }
                    if (hit * 2 >= tot) pr[rI] |= 1 << c;
                }
            int any = 0;
            for (int v : pr) any |= v;
            if (any == 0) continue;
            int slotIdx = Math.min(2, (int) (3f * (minX + maxX) / 2f / w));
            if (slotIdx <= prevSlot) slotIdx = Math.min(2, prevSlot + 1);
            prevSlot = slotIdx;
            Slot slot = res.slots[slotIdx];
            slot.piece = new Piece(pr, cols);
            slot.x = minX; slot.y = minY; slot.w = sw; slot.h = sh;
        }
    }

    public static Result detect(int[] px, int w, int h) {
        Result res = new Result();

        // ---- 1. kotak luar papan (termasuk bingkai) ----
        int y0 = (int) (h * 0.08), y1 = (int) (h * 0.90);
        boolean[] rowOn = new boolean[h];
        int needRow = (int) (w / 3 * 0.70);
        for (int y = y0; y < y1; y++) {
            int bg = bgAt(px, w, y), n = 0;
            for (int x = 0; x < w; x += 3) if (notBg(px[y * w + x], bg)) n++;
            rowOn[y] = n >= needRow;
        }
        int[] rr = longestRun(rowOn, y0, y1 - 1, 6);
        if (rr == null) { res.error = ERR_BOARD; return res; }
        int T = rr[0], B = rr[1];

        boolean[] colOn = new boolean[w];
        int needCol = (int) (((B - T) / 3) * 0.70);
        for (int x = 0; x < w; x++) {
            int n = 0;
            for (int y = T; y <= B; y += 3) if (notBg(px[y * w + x], bgAt(px, w, y))) n++;
            colOn[x] = n >= needCol;
        }
        int[] cr = longestRun(colOn, 0, w - 1, 6);
        if (cr == null) { res.error = ERR_BOARD; return res; }
        int L = cr[0], R = cr[1];

        int size = Math.max(R - L, B - T);
        if (size < w * 0.4f || Math.abs((R - L) - (B - T)) > 0.08f * size) { res.error = ERR_BOARD; return res; }

        // ---- 2. buang bingkai -> kotak grid 8x8 sebenarnya ----
        int maxIn = Math.max(6, (int) (size * 0.06f));
        int[] il = new int[8], ir = new int[8], it = new int[8], ib = new int[8];
        for (int k = 0; k < 8; k++) {
            int yy = T + (int) ((k + 0.5f) * (B - T + 1) / 8f);
            int xx = L + (int) ((k + 0.5f) * (R - L + 1) / 8f);
            il[k] = frameInset(px, w, L + 2, yy, 1, 0, size, maxIn);
            ir[k] = frameInset(px, w, R - 2, yy, -1, 0, size, maxIn);
            it[k] = frameInset(px, w, xx, T + 2, 0, 1, size, maxIn);
            ib[k] = frameInset(px, w, xx, B - 2, 0, -1, size, maxIn);
        }
        int minFrame = Math.max(5, (int) (size * 0.012f)); // inset kecil = tidak ada bingkai (tema polos)
        for (int k = 0; k < 8; k++) {
            if (il[k] < minFrame) il[k] = 0;
            if (ir[k] < minFrame) ir[k] = 0;
            if (it[k] < minFrame) it[k] = 0;
            if (ib[k] < minFrame) ib[k] = 0;
        }
        int gl = L + median(il), gr = R - median(ir);
        int gt = T + median(it), gb = B - median(ib);
        int bw = gr - gl + 1, bh = gb - gt + 1;
        if (Math.abs(bw - bh) > 0.06f * Math.max(bw, bh)) { res.error = ERR_BOARD; return res; }

        res.left = gl; res.top = gt;
        res.cell = (bw + bh) / 16f;
        res.frame = (median(il) + median(ir) + median(it) + median(ib)) / 4f;
        if (gridScore(px, w, h, res) < 0.97f) refineGrid(px, w, h, res);  // geometri awal kurang pas -> setel ulang
        // Validasi: harus ada pola grid 8x8. Wallpaper / layar lain ditolak.
        if (!gridOk(px, w, h, res)) {
            res.error = ERR_BOARD;
            return res;
        }

        // ---- 3. isi 64 sel ----
        gl = Math.round(res.left); gt = Math.round(res.top);
        int rad = Math.max(2, (int) (res.cell * 0.12f));
        int rx = Math.max(2, (int) (res.cell * 0.10f)), ry = Math.max(1, (int) (res.cell * 0.02f));
        int off = (int) (res.cell * 0.41f);
        int[] center = new int[64];
        boolean[] bevel = new boolean[64];
        for (int rI = 0; rI < 8; rI++)
            for (int c = 0; c < 8; c++) {
                int cx = (int) (gl + (c + 0.5f) * res.cell), cy = (int) (gt + (rI + 0.5f) * res.cell);
                int i = rI * 8 + c;
                center[i] = avg(px, w, h, cx, cy, rad, rad);
                int top = avg(px, w, h, cx, cy - off, rx, ry);
                int bot = avg(px, w, h, cx, cy + off, rx, ry);
                bevel[i] = diff(top, bot) > 60;       // sisi atas terang, bawah gelap = ada blok
            }
        // sel rata (kosong): warna tengahnya jadi acuan; sel rata yang warnanya beda jauh = blok polos
        int[] fr = new int[64], fg = new int[64], fb = new int[64];
        int nf = 0;
        for (int i = 0; i < 64; i++) if (!bevel[i]) { fr[nf] = r(center[i]); fg[nf] = g(center[i]); fb[nf] = b(center[i]); nf++; }
        int emptyRef = 0;
        if (nf > 0) {
            emptyRef = 0xFF000000 | median(Arrays.copyOf(fr, nf)) << 16 | median(Arrays.copyOf(fg, nf)) << 8 | median(Arrays.copyOf(fb, nf));
        }
        boolean[] overlay = new boolean[64];
        int nOverlay = 0;
        for (int i = 0; i < 64; i++) {
            float cl = gl + (i % 8) * res.cell, ct = gt + (i / 8) * res.cell;
            overlay[i] = hintOverlayCell(px, w, h, cl, ct, res.cell);
            if (overlay[i]) nOverlay++;
        }
        // Hint paling banyak beberapa blok. Kalau hampir semua sel "berbingkai putih", itu tema game-nya
        // (garis putih tebal), bukan hint kita -> jangan dipakai.
        boolean useMask = nOverlay <= 28;
        res.hintCells = useMask ? nOverlay : 0;
        for (int i = 0; i < 64; i++) {
            boolean filled = bevel[i] || (nf > 0 && diff(center[i], emptyRef) > 70);
            if (useMask && overlay[i]) filled = false;
            if (filled) res.board[i / 8] |= 1 << (i % 8);
        }

        readTray(px, w, h, res);
        return res;
    }
}
