package hint;

import java.util.*;

/**
 * Papan 8x8 = int[8], bit 0 = kolom kiri. Mencari urutan + posisi 3 blok
 * yang (1) paling banyak bisa ditaruh, (2) meninggalkan papan paling aman.
 */
public final class Solver {
    public static final int N = 8, FULL = (1 << N) - 1;
    private static final List<Piece> LIB = Piece.library();

    public static final class Move {
        public final int piece, r, c; // piece = indeks di array input
        Move(int piece, int r, int c) { this.piece = piece; this.r = r; this.c = c; }
        @Override public String toString() { return "blok#" + piece + " @baris" + r + ",kolom" + c; }
    }

    public static final class Plan {
        public final List<Move> moves;
        public final int placed;
        public final double score;
        Plan(List<Move> m, int placed, double score) { this.moves = m; this.placed = placed; this.score = score; }
    }

    public static boolean canPlace(int[] b, Piece p, int r, int c) {
        if (r + p.h > N || c + p.w > N) return false;
        for (int i = 0; i < p.h; i++) if ((b[r + i] & (p.rows[i] << c)) != 0) return false;
        return true;
    }

    /** Taruh blok, hapus baris/kolom penuh. Mengembalikan jumlah garis yang hilang. */
    static int place(int[] b, Piece p, int r, int c) {
        for (int i = 0; i < p.h; i++) b[r + i] |= p.rows[i] << c;
        int rowsFull = 0, colsFull = FULL;
        for (int i = 0; i < N; i++) {
            if (b[i] == FULL) rowsFull |= 1 << i;
            colsFull &= b[i];
        }
        int lines = Integer.bitCount(rowsFull) + Integer.bitCount(colsFull);
        if (lines > 0) {
            for (int i = 0; i < N; i++) b[i] = (rowsFull >> i & 1) != 0 ? 0 : (b[i] & ~colsFull);
        }
        return lines;
    }

    /** Salinan papan setelah blok ditaruh di (r,c) + garis penuh dihapus. null kalau tidak muat. */
    public static int[] simulate(int[] board, Piece p, int r, int c) {
        if (r < 0 || c < 0 || !canPlace(board, p, r, c)) return null;
        int[] nb = board.clone();
        place(nb, p, r, c);
        return nb;
    }

    private static boolean fitsAnywhere(int[] b, Piece p) {
        for (int r = 0; r + p.h <= N; r++)
            for (int c = 0; c + p.w <= N; c++)
                if (canPlace(b, p, r, c)) return true;
        return false;
    }

    // ---------- penilaian papan (bobot bisa dilatih lewat simulasi, lihat DEFAULT_W) ----------

    /** Indeks bobot. */
    public static final int W_FILLED = 0, W_ISO = 1, W_TRANS = 2, W_DEAD = 3, W_SMALL = 4, W_NEAR = 5,
            W_EMPTYLINE = 6, W_LINE = 7, W_COMBO = 8, W_SURV = 9, NW = 10;

    /** Bobot LAMA (sebelum dilatih), dipakai sebagai pembanding di simulasi. */
    public static final double[] OLD_W = {-2.0, -18.0, -1.2, -25.0, 0.0, 0.0, 0.0, 60.0, 40.0, 0.0};

    /**
     * Bobot hasil latihan (cross-entropy method di simulator, lalu digabung dengan lookahead).
     * Urutan: filled, isolated, transitions, dead, smallRegion, nearFull, emptyLine, line, combo, survival.
     */
    public static final double[] DEFAULT_W = {-1.19, -20.93, -2.32, -26.18, -0.52, 0.22, 0.89, 39.55, 35.29, 1000.0};

    public static int beam = 8;
    /** Lookahead: dari lookK papan akhir terbaik, tiap papan dites dengan lookM tray acak berikutnya. 0 = mati. */
    public static int lookK = 12, lookM = 32;

    /** Bentuk yang bisa muncul di game asli (tanpa diagonal 2-sel). */
    private static final List<Piece> DIST = new ArrayList<>();
    static {
        for (Piece p : LIB) if (!(p.cells == 2 && p.h == 2 && p.w == 2)) DIST.add(p);
    }

    /** Bisa menaruh SEMUA blok tray t (urutan bebas) di papan b? Batas simpul supaya tetap cepat. */
    private static boolean feasible(int[] b, Piece[] t, int mask, int[] budget) {
        if (mask == (1 << t.length) - 1) return true;
        if (budget[0]-- <= 0) return true;   // kebanyakan simpul = papan longgar, anggap selamat
        for (int k = 0; k < t.length; k++) {
            if ((mask >> k & 1) != 0) continue;
            Piece p = t[k];
            boolean dupe = false;
            for (int j = 0; j < k; j++) if ((mask >> j & 1) == 0 && t[j] == p) dupe = true;
            if (dupe) continue;
            for (int r = 0; r + p.h <= N; r++) {
                for (int c = 0; c + p.w <= N; c++) {
                    if (!canPlace(b, p, r, c)) continue;
                    int[] nb = b.clone();
                    place(nb, p, r, c);
                    if (feasible(nb, t, mask | 1 << k, budget)) return true;
                }
            }
        }
        return false;
    }

    /** Peluang (0..1) papan b selamat dari tray acak berikutnya, diperkirakan dari sampel. */
    private static double survival(int[] b, Piece[][] samples) {
        int ok = 0;
        for (Piece[] t : samples) if (feasible(b, t, 0, new int[]{4000})) ok++;
        return ok / (double) samples.length;
    }

    /** Fitur murah (tanpa cek "bentuk mana yang tidak muat"). Mengisi f[...] dan mengembalikan nilai berbobot. */
    static double cheap(int[] b, double[] w) {
        int filled = 0, isolated = 0, trans = 0;
        for (int r = 0; r < N; r++) {
            filled += Integer.bitCount(b[r]);
            for (int c = 0; c < N; c++) {
                boolean f = (b[r] >> c & 1) != 0;
                if (c + 1 < N && f != ((b[r] >> (c + 1) & 1) != 0)) trans++;
                if (r + 1 < N && f != ((b[r + 1] >> c & 1) != 0)) trans++;
                if (!f) {
                    boolean u = r == 0 || (b[r - 1] >> c & 1) != 0;
                    boolean d = r == N - 1 || (b[r + 1] >> c & 1) != 0;
                    boolean l = c == 0 || (b[r] >> (c - 1) & 1) != 0;
                    boolean rt = c == N - 1 || (b[r] >> (c + 1) & 1) != 0;
                    if (u && d && l && rt) isolated++;
                }
            }
        }
        double s = filled * w[W_FILLED] + isolated * w[W_ISO] + trans * w[W_TRANS];
        if (w[W_SMALL] != 0) s += smallRegionCells(b) * w[W_SMALL];
        if (w[W_NEAR] != 0 || w[W_EMPTYLINE] != 0) {
            int near = 0, empty = 0, colMask = FULL;
            int[] colCnt = new int[N];
            for (int r = 0; r < N; r++) {
                int rc = Integer.bitCount(b[r]);
                if (rc >= N - 2 && rc < N) near++;
                if (rc == 0) empty++;
                for (int c = 0; c < N; c++) colCnt[c] += b[r] >> c & 1;
            }
            for (int c = 0; c < N; c++) {
                if (colCnt[c] >= N - 2 && colCnt[c] < N) near++;
                if (colCnt[c] == 0) empty++;
            }
            s += near * w[W_NEAR] + empty * w[W_EMPTYLINE];
        }
        return s;
    }

    /** Jumlah sel kosong yang berada di "kantong" tertutup kecil (< 4 sel): sulit/mustahil diisi blok. */
    private static int smallRegionCells(int[] b) {
        int[] seen = new int[N];
        int total = 0;
        int[] stack = new int[N * N];
        for (int r = 0; r < N; r++) {
            for (int c = 0; c < N; c++) {
                if ((b[r] >> c & 1) != 0 || (seen[r] >> c & 1) != 0) continue;
                int sp = 0, size = 0;
                stack[sp++] = r * N + c;
                seen[r] |= 1 << c;
                while (sp > 0) {
                    int v = stack[--sp];
                    int vr = v / N, vc = v % N;
                    size++;
                    if (vr > 0 && (b[vr - 1] >> vc & 1) == 0 && (seen[vr - 1] >> vc & 1) == 0) { seen[vr - 1] |= 1 << vc; stack[sp++] = (vr - 1) * N + vc; }
                    if (vr < N - 1 && (b[vr + 1] >> vc & 1) == 0 && (seen[vr + 1] >> vc & 1) == 0) { seen[vr + 1] |= 1 << vc; stack[sp++] = (vr + 1) * N + vc; }
                    if (vc > 0 && (b[vr] >> (vc - 1) & 1) == 0 && (seen[vr] >> (vc - 1) & 1) == 0) { seen[vr] |= 1 << (vc - 1); stack[sp++] = vr * N + vc - 1; }
                    if (vc < N - 1 && (b[vr] >> (vc + 1) & 1) == 0 && (seen[vr] >> (vc + 1) & 1) == 0) { seen[vr] |= 1 << (vc + 1); stack[sp++] = vr * N + vc + 1; }
                }
                if (size < 4) total += size;
            }
        }
        return total;
    }

    /** Nilai papan akhir: makin tinggi makin aman. */
    static double evaluate(int[] b, double[] w) {
        double s = cheap(b, w);
        int dead = 0;
        for (Piece p : LIB) if (!fitsAnywhere(b, p)) dead++;
        return s + dead * w[W_DEAD];
    }

    private static double lineGain(int lines, double[] w) {
        return lines * w[W_LINE] + (lines > 1 ? (lines - 1) * w[W_COMBO] : 0);
    }


    // ---------- lookahead 2 lapis (tray berikutnya dimainkan juga) ----------

    /** Jumlah kandidat akhir yang dinilai dalam, sampel tray, dan lebar beam di lapis kedua. 0 = mati. */
    public static int deepK = 6, deepM = 16, deepBeam = 2;
    /** Batas waktu hitung (ms) untuk tahap lookahead. Kalau lewat, pakai kandidat terbaik yang sudah dinilai. */
    public static long budgetMs = 1500;
    /** Bobot nilai lapis kedua dan hukuman kalau tray sampel tidak bisa ditaruh sama sekali. */
    public static double deepW = 0.5, deepDead = 250.0;
    private static final double NONE = -1e18;

    /** Nilai terbaik (garis + cheap papan akhir) untuk menaruh SEMUA blok tray t di papan b, atau NONE kalau mustahil. */
    private static double bestSeq(int[] b, Piece[] t, int mask, double[] w, int bm) {
        int n = t.length;
        if (mask == (1 << n) - 1) return cheap(b, w);
        double best = NONE;
        for (int k = 0; k < n; k++) {
            if ((mask >> k & 1) != 0) continue;
            Piece p = t[k];
            boolean dupe = false;
            for (int j = 0; j < k; j++) if ((mask >> j & 1) == 0 && t[j] == p) dupe = true;
            if (dupe) continue;
            double[] qs = new double[bm];
            int[] ar = new int[bm], ac = new int[bm], al = new int[bm];
            Arrays.fill(qs, NONE);
            for (int r = 0; r + p.h <= N; r++) {
                for (int c = 0; c + p.w <= N; c++) {
                    if (!canPlace(b, p, r, c)) continue;
                    int[] nb = b.clone();
                    int lines = place(nb, p, r, c);
                    double q = lineGain(lines, w) + cheap(nb, w);
                    int pos = -1;
                    for (int i = 0; i < bm; i++) if (q > qs[i]) { pos = i; break; }
                    if (pos < 0) continue;
                    for (int i = bm - 1; i > pos; i--) { qs[i] = qs[i - 1]; ar[i] = ar[i - 1]; ac[i] = ac[i - 1]; al[i] = al[i - 1]; }
                    qs[pos] = q; ar[pos] = r; ac[pos] = c; al[pos] = lines;
                }
            }
            for (int i = 0; i < bm; i++) {
                if (qs[i] == NONE) break;
                int[] nb = b.clone();
                place(nb, p, ar[i], ac[i]);
                double rest = bestSeq(nb, t, mask | 1 << k, w, bm);
                if (rest == NONE) continue;
                double v = lineGain(al[i], w) + rest;
                if (v > best) best = v;
            }
        }
        return best;
    }

    /** Rata-rata nilai papan b setelah tray acak berikutnya dimainkan sebaik mungkin; tray yang mustahil kena deepDead. */
    private static double deepValue(int[] b, Piece[][] samples, int m, double[] w) {
        double sum = 0;
        for (int i = 0; i < m; i++) {
            double v = bestSeq(b, samples[i], 0, w, deepBeam);
            sum += v == NONE ? -deepDead : Math.max(v, -deepDead);
        }
        return sum / m;
    }

    private static long key(int[] b) {
        long k = 0;
        for (int i = 0; i < N; i++) k = k << 8 | (b[i] & 0xFF);
        return k;
    }

    private static final class Search {
        final Piece[] pieces;
        final double[] w;
        double bestScore = -1e18;
        List<Move> best = new ArrayList<>();
        int bestPlaced = -1;
        final List<Object[]> leaves = new ArrayList<>();   // {papan, skor, jalur, placed} untuk lookahead

        Search(Piece[] p, double[] w) { pieces = p; this.w = w; }

        void run(int[] b, int usedMask, List<Move> path, double gain, int placed) {
            boolean any = false;
            if (placed < pieces.length) {
                List<double[]> cand = new ArrayList<>();
                for (int k = 0; k < pieces.length; k++) {
                    if ((usedMask >> k & 1) != 0) continue;
                    Piece p = pieces[k];
                    for (int r = 0; r + p.h <= N; r++) {
                        for (int c = 0; c + p.w <= N; c++) {
                            if (!canPlace(b, p, r, c)) continue;
                            int[] nb = b.clone();
                            int lines = place(nb, p, r, c);
                            cand.add(new double[]{lineGain(lines, w) + cheap(nb, w), k, r, c, lines});
                        }
                    }
                }
                any = !cand.isEmpty();
                Collections.sort(cand, new Comparator<double[]>() {
                    public int compare(double[] x, double[] y) { return Double.compare(y[0], x[0]); }
                });
                int[] perPiece = new int[pieces.length];
                for (double[] cd : cand) {
                    int k = (int) cd[1];
                    if (perPiece[k] >= beam) continue;
                    perPiece[k]++;
                    int r = (int) cd[2], c = (int) cd[3], lines = (int) cd[4];
                    int[] nb = b.clone();
                    place(nb, pieces[k], r, c);
                    path.add(new Move(k, r, c));
                    run(nb, usedMask | 1 << k, path, gain + lineGain(lines, w), placed + 1);
                    path.remove(path.size() - 1);
                }
            }
            if (!any) {
                double sc = gain + evaluate(b, w);
                if (placed > bestPlaced || (placed == bestPlaced && sc > bestScore)) {
                    bestPlaced = placed; bestScore = sc; best = new ArrayList<>(path);
                }
                if (lookK > 0) leaves.add(new Object[]{b, sc, new ArrayList<>(path), placed});
            }
        }
    }

    public static Plan solve(int[] board, Piece[] pieces) { return solve(board, pieces, DEFAULT_W); }

    public static Plan solve(int[] board, Piece[] pieces, double[] w) {
        long t0 = System.currentTimeMillis();
        Search s = new Search(pieces, w);
        s.run(board.clone(), 0, new ArrayList<Move>(), 0, 0);
        if (lookK > 0 && lookM > 0 && w[W_SURV] != 0 && s.bestPlaced == pieces.length && !s.leaves.isEmpty()) {
            // buang papan akhir kembar (urutan beda, hasil sama), simpan yang skornya paling tinggi
            Map<Long, Object[]> uniq = new HashMap<>();
            for (Object[] lf : s.leaves) {
                if ((Integer) lf[3] != s.bestPlaced) continue;
                long k = key((int[]) lf[0]);
                Object[] old = uniq.get(k);
                if (old == null || (Double) lf[1] > (Double) old[1]) uniq.put(k, lf);
            }
            List<Object[]> top = new ArrayList<>(uniq.values());
            Collections.sort(top, new Comparator<Object[]>() {
                public int compare(Object[] x, Object[] y) { return Double.compare((Double) y[1], (Double) x[1]); }
            });
            int boardHash = Arrays.hashCode(board);
            Random rnd = new Random(boardHash * 31L + pieces.length);
            int total = Math.max(lookM, deepM);
            Piece[][] samples = new Piece[total][3];
            for (int i = 0; i < total; i++) for (int j = 0; j < 3; j++) samples[i][j] = DIST.get(rnd.nextInt(DIST.size()));

            int nk = Math.min(lookK, top.size());
            double[] sc1 = new double[nk];
            Integer[] order = new Integer[nk];
            for (int i = 0; i < nk; i++) {
                Object[] lf = top.get(i);
                Piece[][] sm = samples;
                int ok = 0;
                for (int j = 0; j < lookM; j++) if (feasible((int[]) lf[0], sm[j], 0, new int[]{4000})) ok++;
                sc1[i] = (Double) lf[1] + w[W_SURV] * (ok / (double) lookM);
                order[i] = i;
            }
            final double[] f1 = sc1;
            Arrays.sort(order, new Comparator<Integer>() {
                public int compare(Integer x, Integer y) { return Double.compare(f1[y], f1[x]); }
            });
            int bi = order[0];
            double bestSc = sc1[bi];
            if (deepK > 0 && deepM > 0 && nk > 1) {
                bestSc = -1e18;
                for (int i = 0; i < Math.min(deepK, nk); i++) {
                    if (i > 0 && System.currentTimeMillis() - t0 > budgetMs) break;   // HP lambat: cukup sampai sini
                    int idx = order[i];
                    double sc = sc1[idx] + deepW * deepValue((int[]) top.get(idx)[0], samples, deepM, w);
                    if (sc > bestSc) { bestSc = sc; bi = idx; }
                }
            }
            @SuppressWarnings("unchecked") List<Move> mv = (List<Move>) top.get(bi)[2];
            return new Plan(mv, s.bestPlaced, bestSc);
        }
        return new Plan(s.best, s.bestPlaced, s.bestScore);
    }
}
