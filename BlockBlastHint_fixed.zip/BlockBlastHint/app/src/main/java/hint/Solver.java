package hint;

import java.util.*;

/**
 * Papan 8x8 = int[8], bit 0 = kolom kiri. Mencari urutan + posisi 3 blok
 * yang (1) paling banyak bisa ditaruh, (2) meninggalkan papan paling aman.
 */
public final class Solver {
    public static final int N = 8, FULL = (1 << N) - 1;
    private static final List<Piece> LIB = Piece.library();

    public static final class Move {
        public final int piece, r, c; // piece = indeks di array input
        Move(int piece, int r, int c) { this.piece = piece; this.r = r; this.c = c; }
        @Override public String toString() { return "blok#" + piece + " @baris" + r + ",kolom" + c; }
    }

    public static final class Plan {
        public final List<Move> moves;
        public final int placed;
        public final double score;
        Plan(List<Move> m, int placed, double score) { this.moves = m; this.placed = placed; this.score = score; }
    }

    public static boolean canPlace(int[] b, Piece p, int r, int c) {
        if (r + p.h > N || c + p.w > N) return false;
        for (int i = 0; i < p.h; i++) if ((b[r + i] & (p.rows[i] << c)) != 0) return false;
        return true;
    }

    /** Taruh blok, hapus baris/kolom penuh. Mengembalikan jumlah garis yang hilang. */
    static int place(int[] b, Piece p, int r, int c) {
        for (int i = 0; i < p.h; i++) b[r + i] |= p.rows[i] << c;
        int rowsFull = 0, colsFull = FULL;
        for (int i = 0; i < N; i++) {
            if (b[i] == FULL) rowsFull |= 1 << i;
            colsFull &= b[i];
        }
        int lines = Integer.bitCount(rowsFull) + Integer.bitCount(colsFull);
        if (lines > 0) {
            for (int i = 0; i < N; i++) b[i] = (rowsFull >> i & 1) != 0 ? 0 : (b[i] & ~colsFull);
        }
        return lines;
    }

    private static boolean fitsAnywhere(int[] b, Piece p) {
        for (int r = 0; r + p.h <= N; r++)
            for (int c = 0; c + p.w <= N; c++)
                if (canPlace(b, p, r, c)) return true;
        return false;
    }

    /** Nilai papan akhir: makin tinggi makin aman. */
    static double evaluate(int[] b) {
        double s = cheap(b);
        int dead = 0;
        for (Piece p : LIB) if (!fitsAnywhere(b, p)) dead++;
        return s - dead * 25.0;
    }

    static double cheap(int[] b) {
        double s = 0;
        int filled = 0;
        for (int r : b) filled += Integer.bitCount(r);
        s -= filled * 2.0;

        int isolated = 0, trans = 0;
        for (int r = 0; r < N; r++) {
            for (int c = 0; c < N; c++) {
                boolean f = (b[r] >> c & 1) != 0;
                if (c + 1 < N && f != ((b[r] >> (c + 1) & 1) != 0)) trans++;
                if (r + 1 < N && f != ((b[r + 1] >> c & 1) != 0)) trans++;
                if (!f) {
                    boolean u = r == 0 || (b[r - 1] >> c & 1) != 0;
                    boolean d = r == N - 1 || (b[r + 1] >> c & 1) != 0;
                    boolean l = c == 0 || (b[r] >> (c - 1) & 1) != 0;
                    boolean rt = c == N - 1 || (b[r] >> (c + 1) & 1) != 0;
                    if (u && d && l && rt) isolated++;
                }
            }
        }
        s -= isolated * 18.0;
        s -= trans * 1.2;
        return s;
    }

        private static final int BEAM = 8;

    private static final class Search {
        final Piece[] pieces;
        double bestScore = -1e18;
        List<Move> best = new ArrayList<>();
        int bestPlaced = -1;

        Search(Piece[] p) { pieces = p; }

        void run(int[] b, int usedMask, List<Move> path, double gain, int placed) {
            boolean any = false;
            if (placed < pieces.length) {
                List<double[]> cand = new ArrayList<>();
                for (int k = 0; k < pieces.length; k++) {
                    if ((usedMask >> k & 1) != 0) continue;
                    Piece p = pieces[k];
                    for (int r = 0; r + p.h <= N; r++) {
                        for (int c = 0; c + p.w <= N; c++) {
                            if (!canPlace(b, p, r, c)) continue;
                            int[] nb = b.clone();
                            int lines = place(nb, p, r, c);
                            double q = lines * 60.0 + (lines > 1 ? (lines - 1) * 40.0 : 0) + cheap(nb);
                            cand.add(new double[]{q, k, r, c, lines});
                        }
                    }
                }
                any = !cand.isEmpty();
                Collections.sort(cand, new Comparator<double[]>() {
                    public int compare(double[] x, double[] y) { return Double.compare(y[0], x[0]); }
                });
                int[] perPiece = new int[pieces.length];
                for (double[] cd : cand) {
                    int k = (int) cd[1];
                    if (perPiece[k] >= BEAM) continue;
                    perPiece[k]++;
                    int r = (int) cd[2], c = (int) cd[3], lines = (int) cd[4];
                    int[] nb = b.clone();
                    place(nb, pieces[k], r, c);
                    path.add(new Move(k, r, c));
                    run(nb, usedMask | 1 << k, path,
                        gain + lines * 60.0 + (lines > 1 ? (lines - 1) * 40.0 : 0), placed + 1);
                    path.remove(path.size() - 1);
                }
            }
            if (!any) {
                double sc = gain + evaluate(b);
                if (placed > bestPlaced || (placed == bestPlaced && sc > bestScore)) {
                    bestPlaced = placed; bestScore = sc; best = new ArrayList<>(path);
                }
            }
        }
    }

    public static Plan solve(int[] board, Piece[] pieces) {
        Search s = new Search(pieces);
        s.run(board.clone(), 0, new ArrayList<Move>(), 0, 0);
        return new Plan(s.best, s.bestPlaced, s.bestScore);
    }
}
