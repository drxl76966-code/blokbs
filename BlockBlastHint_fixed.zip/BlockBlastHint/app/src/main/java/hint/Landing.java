package hint;

import java.util.Arrays;

/** Mencari tahu ke mana sebuah blok SEBENARNYA mendarat setelah di-drag, dengan membandingkan papan sebelum/sesudah. */
public final class Landing {
    private Landing() { }

    /**
     * @param before papan sebelum drag
     * @param after  papan sesudah drag (sudah termasuk garis yang terhapus)
     * @return {dr, dc} = selisih posisi mendarat terhadap (r,c) yang dituju, atau null kalau tidak ada
     *         posisi yang cocok (blok tidak menempel / papan terbaca salah).
     */
    public static int[] find(int[] before, Piece p, int r, int c, int[] after) {
        int[] best = null;
        int bestD = Integer.MAX_VALUE;
        for (int dr = -5; dr <= 5; dr++) {
            for (int dc = -5; dc <= 5; dc++) {
                int[] sim = Solver.simulate(before, p, r + dr, c + dc);
                if (sim == null || !Arrays.equals(sim, after)) continue;
                int d = Math.abs(dr) + Math.abs(dc);
                if (d < bestD) { bestD = d; best = new int[]{dr, dc}; }
            }
        }
        return best;
    }
}
