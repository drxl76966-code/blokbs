package com.bbhint;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Cuma dipakai untuk menyeret blok (dispatchGesture). Tidak membaca isi layar / event apa pun.
 * Harus diaktifkan manual di Pengaturan > Aksesibilitas.
 */
public class AutoPlayService extends AccessibilityService {
    /** Diisi saat service aktif, null kalau belum/sudah dimatikan. */
    public static volatile AutoPlayService instance;

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override public boolean onUnbind(android.content.Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    @Override public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override public void onInterrupt() { }

    /**
     * Seret jari dari (sx,sy) ke (tx,ty), tahan sebentar di tujuan, lalu lepas. MEMBLOKIR sampai selesai,
     * jadi jangan dipanggil dari main thread. Koordinat dalam piksel layar.
     *
     * @return true kalau gesture selesai dijalankan sistem
     */
    public boolean drag(float sx, float sy, final float tx, final float ty, int screenW, int screenH)
            throws InterruptedException {
        sx = clamp(sx, 1, screenW - 2);
        sy = clamp(sy, 1, screenH - 2);
        final float fx = clamp(tx, 1, screenW - 2), fy = clamp(ty, 1, screenH - 2);

        double dist = Math.hypot(fx - sx, fy - sy);
        long dur = (long) Math.min(900, Math.max(450, dist * 0.6));

        final CountDownLatch done = new CountDownLatch(1);
        final boolean[] ok = {false};

        Path p1 = new Path();
        p1.moveTo(sx, sy);
        p1.lineTo(fx, fy);
        final GestureDescription.StrokeDescription s1 = new GestureDescription.StrokeDescription(p1, 0, dur, true);

        boolean sent = dispatchGesture(new GestureDescription.Builder().addStroke(s1).build(),
                new GestureResultCallback() {
                    @Override public void onCompleted(GestureDescription d) {
                        // tahan jari di tujuan sebentar supaya game sempat memproses posisi akhir, lalu lepas
                        Path p2 = new Path();
                        p2.moveTo(fx, fy);
                        GestureDescription.StrokeDescription s2 = s1.continueStroke(p2, 0, 250, false);
                        boolean sent2 = dispatchGesture(new GestureDescription.Builder().addStroke(s2).build(),
                                new GestureResultCallback() {
                                    @Override public void onCompleted(GestureDescription d2) { ok[0] = true; done.countDown(); }
                                    @Override public void onCancelled(GestureDescription d2) { done.countDown(); }
                                }, null);
                        if (!sent2) done.countDown();
                    }
                    @Override public void onCancelled(GestureDescription d) { done.countDown(); }
                }, null);
        if (!sent) return false;
        done.await(dur + 4000, TimeUnit.MILLISECONDS);
        return ok[0];
    }

    private static float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }
}
