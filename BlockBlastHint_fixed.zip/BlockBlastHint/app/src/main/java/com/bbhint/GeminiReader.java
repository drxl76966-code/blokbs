package com.bbhint;

import android.graphics.Bitmap;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import hint.Detector;
import hint.GeminiParse;

/** Minta Gemini membaca papan + blok dari potongan screenshot. Panggil dari thread kerja, bukan main thread. */
public final class GeminiReader {
    private static final String PROMPT =
            "This is a cropped screenshot of the puzzle game Block Blast. At the top is an 8x8 board; "
            + "below it is a tray with up to 3 pieces (left, middle, right).\n"
            + "Ignore any semi-transparent colored squares with white outlines or numbers drawn on top of the board: "
            + "they are overlay hints, so treat those cells as EMPTY.\n"
            + "Reply in EXACTLY this plain text format and nothing else:\n"
            + "BOARD\n"
            + "<8 lines of 8 characters, top row first, left column first; 1 = cell contains a block, 0 = empty cell>\n"
            + "P1: <left piece>\nP2: <middle piece>\nP3: <right piece>\n"
            + "A piece is written as its bounding box with rows separated by '/', X for a block and . for empty, "
            + "for example an L piece is XX/X. and a 1x3 vertical bar is X/X/X. Write NONE if a tray slot is empty.";

    private GeminiReader() { }

    public static GeminiParse.Reading read(int[] px, int w, int h, Detector.Result r, String key, String model) {
        GeminiParse.Reading fail = new GeminiParse.Reading();
        HttpURLConnection c = null;
        try {
            byte[] jpg = cropJpeg(px, w, h, r);
            String b64 = Base64.encodeToString(jpg, Base64.NO_WRAP);

            JSONObject inline = new JSONObject().put("mime_type", "image/jpeg").put("data", b64);
            JSONArray parts = new JSONArray()
                    .put(new JSONObject().put("inline_data", inline))
                    .put(new JSONObject().put("text", PROMPT));
            JSONObject body = new JSONObject()
                    .put("contents", new JSONArray().put(new JSONObject().put("parts", parts)))
                    .put("generationConfig", new JSONObject().put("temperature", 0));

            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent");
            c = (HttpURLConnection) url.openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(8000);
            c.setReadTimeout(40000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("x-goog-api-key", key);
            OutputStream os = c.getOutputStream();
            os.write(body.toString().getBytes("UTF-8"));
            os.close();

            int code = c.getResponseCode();
            String resp = readAll(code >= 400 ? c.getErrorStream() : c.getInputStream());
            if (code != 200) {
                fail.error = "HTTP " + code + (code == 400 || code == 403 ? " (cek API key / nama model)" : code == 429 ? " (kuota habis)" : "");
                return fail;
            }
            JSONObject j = new JSONObject(resp);
            JSONArray ps = j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts");
            StringBuilder text = new StringBuilder();
            for (int i = 0; i < ps.length(); i++) text.append(ps.getJSONObject(i).optString("text", "")).append('\n');
            return GeminiParse.parse(text.toString());
        } catch (Exception e) {
            fail.error = e.getClass().getSimpleName();
            return fail;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /** Hanya area papan + tray yang dikirim (bukan seluruh layar), lebar maks 720 px. */
    private static byte[] cropJpeg(int[] px, int w, int h, Detector.Result r) {
        int y0 = Math.max(0, (int) (r.top - r.cell * 0.2f));
        int y1 = Math.min(h, (int) (r.top + r.cell * 11.6f));
        Bitmap full = Bitmap.createBitmap(px, y0 * w, w, w, y1 - y0, Bitmap.Config.ARGB_8888);
        Bitmap send = full;
        if (w > 720) send = Bitmap.createScaledBitmap(full, 720, Math.max(1, (y1 - y0) * 720 / w), true);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        send.compress(Bitmap.CompressFormat.JPEG, 88, bos);
        if (send != full) send.recycle();
        full.recycle();
        return bos.toByteArray();
    }

    private static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        in.close();
        return bos.toString("UTF-8");
    }
}
