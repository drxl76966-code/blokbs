package com.bbhint;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 100;

    private TextView status;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = dp(20);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad * 2, pad, pad);

        TextView title = new TextView(this);
        title.setText("BB Hint");
        title.setTextSize(24);
        title.setTextColor(0xFF111111);
        root.addView(title);

        status = new TextView(this);
        status.setTextSize(14);
        status.setTextColor(0xFF444444);
        status.setPadding(0, dp(8), 0, dp(16));
        root.addView(status);

        root.addView(button("1. Izinkan tampil di atas aplikasi lain", new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            }
        }));
        root.addView(button("2. Mulai (izin rekam layar)", new View.OnClickListener() {
            public void onClick(View v) { start(); }
        }));
        root.addView(button("3. (Opsional) Aktifkan Auto Play di Aksesibilitas", new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        }));

        TextView note = new TextView(this);
        note.setTextSize(12);
        note.setTextColor(0xFF666666);
        note.setPadding(0, dp(12), 0, 0);
        note.setText("Auto Play: cari \"BB Hint Auto Play\" lalu nyalakan. Kalau tombolnya abu-abu (Android 13+): "
                + "buka Info Aplikasi BB Hint > menu titik tiga > \"Izinkan setelan terbatas\", lalu ulangi. "
                + "Setelah itu mulai game, tekan tombol \"Main\" di panel bawah.");
        root.addView(note);


        TextView gTitle = new TextView(this);
        gTitle.setText("Gemini (opsional)");
        gTitle.setTextSize(16);
        gTitle.setTextColor(0xFF111111);
        gTitle.setPadding(0, dp(24), 0, dp(4));
        root.addView(gTitle);

        TextView gNote = new TextView(this);
        gNote.setTextSize(12);
        gNote.setTextColor(0xFF666666);
        gNote.setText("Dipakai hanya sebagai pemeriksa: kalau solver bilang blok tidak muat semua, Gemini diminta "
                + "baca ulang layar. Yang dikirim cuma potongan papan dan blok. Langkah tetap dihitung solver. "
                + "Kunci API gratis dari Google AI Studio. Di paket gratis, Google bisa memakai kiriman itu untuk "
                + "memperbaiki produknya.");
        root.addView(gNote);

        final SharedPreferences sp = getSharedPreferences("bbhint", MODE_PRIVATE);
        final CheckBox gOn = new CheckBox(this);
        gOn.setText("Pakai Gemini sebagai pemeriksa");
        gOn.setChecked(sp.getBoolean("gemini_on", false));
        root.addView(gOn);

        final EditText gKey = new EditText(this);
        gKey.setHint("API key Gemini");
        gKey.setSingleLine(true);
        gKey.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        gKey.setText(sp.getString("gemini_key", ""));
        root.addView(gKey);

        final EditText gModel = new EditText(this);
        gModel.setHint("Nama model (kosong = gemini-3.1-flash-lite)");
        gModel.setSingleLine(true);
        gModel.setText(sp.getString("gemini_model", ""));
        root.addView(gModel);

        root.addView(button("Simpan pengaturan Gemini", new View.OnClickListener() {
            public void onClick(View v) {
                sp.edit().putBoolean("gemini_on", gOn.isChecked())
                        .putString("gemini_key", gKey.getText().toString().trim())
                        .putString("gemini_model", gModel.getText().toString().trim())
                        .apply();
                Toast.makeText(MainActivity.this, "Tersimpan", Toast.LENGTH_SHORT).show();
            }
        }));

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        String s = "Overlay: " + (Settings.canDrawOverlays(this) ? "diizinkan" : "belum")
                + "\nAuto Play (aksesibilitas): " + (AutoPlayService.instance != null ? "aktif" : "belum");
        status.setText(s);
    }

    private void start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan overlay dulu (langkah 1)", Toast.LENGTH_SHORT).show();
            return;
        }
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req != REQ_CAPTURE) return;
        if (result != RESULT_OK || data == null) {
            Toast.makeText(this, "Izin rekam layar ditolak", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent svc = new Intent(this, CaptureService.class);
        svc.putExtra("code", result);
        svc.putExtra("data", data);
        startForegroundService(svc);
        moveTaskToBack(true);
    }

    private Button button(String t, View.OnClickListener l) {
        Button bt = new Button(this);
        bt.setText(t);
        bt.setAllCaps(false);
        bt.setOnClickListener(l);
        return bt;
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
}
