package com.bbhint;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import hint.Calib;
import hint.Detector;
import hint.Landing;
import hint.Piece;
import hint.Solver;

public class CaptureService extends Service {
    public static final String ACTION_STOP = "stop";
    private static final String CHANNEL = "bbhint";

    private final Handler main = new Handler(Looper.getMainLooper());
    private HandlerThread workThread;
    private Handler work;

    private MediaProjection projection;
    private ImageReader reader;
    private VirtualDisplay vdisplay;
    private WindowManager wm;
    private int sw, sh;

    private final Object frameLock = new Object();
    private Image held;

    private HintView hintView;
    private LinearLayout panel;
    private Button autoBtn;

    private volatile boolean autoOn;
    private volatile boolean forceReset;
    private volatile boolean playOn;
    private volatile int playGen;
    private Thread playThread;
    private Button playBtn;
    private Calib calib;
    private SharedPreferences prefs;

    private String lastPlanSig;       // cache rencana terakhir (hanya dipakai dari satu thread kerja sekaligus)
    private Solver.Plan lastPlan;
    private volatile int autoGen;   // naik tiap auto dimatiin/dinyalain, supaya loop & post lama dibuang
    private Thread autoThread;

    private static final class Analysis {
        String error;
        Detector.Result res;
        Solver.Plan plan;
        Piece[] pieces;
        int[] slotOf;
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent in, int flags, int startId) {
        if (in == null || ACTION_STOP.equals(in.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startFg();   // wajib dipanggil tiap startForegroundService(), juga saat service sudah jalan
        if (projection != null) return START_NOT_STICKY;

        int code = in.getIntExtra("code", 0);
        Intent data = (Intent) in.getParcelableExtra("data");
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(code, data);
        if (projection == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        workThread = new HandlerThread("bbhint-work");
        workThread.start();
        work = new Handler(workThread.getLooper());

        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { main.post(new Runnable() { public void run() { stopSelf(); } }); }
        }, main);

        prefs = getSharedPreferences("bbhint", MODE_PRIVATE);
        calib = Calib.load(prefs.getString("calib", null));

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        sw = dm.widthPixels;
        sh = dm.heightPixels;

        reader = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 3);
        reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            @Override public void onImageAvailable(ImageReader r) {
                Image im = null;
                try { im = r.acquireLatestImage(); } catch (Exception ignored) { }
                if (im == null) return;
                synchronized (frameLock) {
                    if (held != null) held.close();
                    held = im;
                }
            }
        }, work);
        vdisplay = projection.createVirtualDisplay("bbhint", sw, sh, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null);

        addOverlay();
        toggleAuto(); // langsung otomatis, tidak perlu dipencet
        return START_NOT_STICKY;
    }

    private void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "BB Hint", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("BB Hint aktif")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, n);
        }
    }

    // ---------- overlay ----------

    private void addOverlay() {
        int type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;

        hintView = new HintView(this);
        WindowManager.LayoutParams hp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        hp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) {
            hp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        wm.addView(hintView, hp);

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        panel.setBackgroundColor(0xE6222222);
        Button hintBtn = makeBtn("Hint");
        autoBtn = makeBtn("Auto: mati");
        playBtn = makeBtn("Main: mati");
        Button closeBtn = makeBtn("Tutup");
        panel.addView(hintBtn);
        panel.addView(autoBtn);
        panel.addView(playBtn);
        panel.addView(closeBtn);
        hintBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { doHint(); } });
        autoBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { toggleAuto(); } });
        playBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { togglePlay(); } });
        closeBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { stopSelf(); } });

        WindowManager.LayoutParams pp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        pp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        pp.y = 40;
        wm.addView(panel, pp);
    }

    private Button makeBtn(String t) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setTextColor(0xFFFFFFFF);
        b.setBackgroundColor(0x00000000);
        return b;
    }

    private void setUiVisible(boolean v) {
        int vis = v ? View.VISIBLE : View.INVISIBLE;
        if (hintView != null) hintView.setVisibility(vis);
        if (panel != null) panel.setVisibility(vis);
    }

    private void toast(final String s) {
        main.post(new Runnable() { public void run() { Toast.makeText(CaptureService.this, s, Toast.LENGTH_SHORT).show(); } });
    }

    // ---------- hint ----------

    /** Hint manual: tekan sekali, hint untuk 3 blok di layar muncul. */
    private void doHint() {
        if (playOn) { toast("Matikan Main dulu untuk pakai Hint"); return; }
        if (autoOn) { forceReset = true; return; }
        hintView.clear();
        setUiVisible(false);
        work.postDelayed(new Runnable() {
            @Override public void run() {
                Analysis tmp;
                try {
                    tmp = analyze();
                } catch (RuntimeException e) {
                    tmp = new Analysis();
                    tmp.error = "Gagal membaca layar: " + e.getClass().getSimpleName();
                }
                final Analysis a = tmp;
                main.post(new Runnable() {
                    @Override public void run() {
                        setUiVisible(true);
                        if (a.error != null) toast(a.error);
                        else hintView.show(a.res, a.plan, a.pieces, a.slotOf);
                    }
                });
            }
        }, 350);
    }

    /** Baca layar saat overlay disembunyikan. Null kalau belum ada gambar. */
    private Detector.Result detectNow() {
        int[] wh = new int[2];
        int[] px = grabPixels(wh);
        if (px == null) return null;
        return Detector.detect(px, wh[0], wh[1]);
    }

    private Analysis analyze() {
        Analysis a = new Analysis();
        Detector.Result r = detectNow();
        if (r == null) { a.error = "Belum ada gambar layar, coba lagi"; return a; }
        if (r.error != null) { a.error = r.error; return a; }
        return plan(r, a);
    }

    private synchronized Analysis plan(Detector.Result r, Analysis a) {
        List<Piece> ps = new ArrayList<>();
        List<Integer> slots = new ArrayList<>();
        for (int s = 0; s < 3; s++) {
            if (r.slots[s] != null && r.slots[s].piece != null) {
                ps.add(r.slots[s].piece);
                slots.add(s);
            }
        }
        if (ps.isEmpty()) { a.error = "Blok di bawah tidak terbaca"; return a; }

        Piece[] arr = ps.toArray(new Piece[0]);
        // papan + blok yang sama (mis. layar game over) tidak perlu dihitung ulang tiap 0,5 detik
        String sig = signature(r);
        Solver.Plan plan;
        if (sig.equals(lastPlanSig) && lastPlan != null) {
            plan = lastPlan;
        } else {
            plan = Solver.solve(r.board, arr);
            lastPlanSig = sig;
            lastPlan = plan;
        }
        if (plan.placed == 0) { a.error = "Tidak ada tempat yang muat"; return a; }

        a.res = r;
        a.plan = plan;
        a.pieces = arr;
        a.slotOf = new int[slots.size()];
        for (int i = 0; i < a.slotOf.length; i++) a.slotOf[i] = slots.get(i);
        return a;
    }

    /** Konversi frame terakhir ke 0xAARRGGBB. wh diisi lebar & tinggi. */
    private int[] grabPixels(int[] wh) {
        synchronized (frameLock) {
            if (held == null) return null;
            int iw = held.getWidth(), ih = held.getHeight();
            Image.Plane pl = held.getPlanes()[0];
            ByteBuffer buf = pl.getBuffer();
            int rs = pl.getRowStride();
            int[] px = new int[iw * ih];
            byte[] row = new byte[iw * 4];
            for (int y = 0; y < ih; y++) {
                buf.position(y * rs);
                buf.get(row, 0, iw * 4);
                int o = y * iw;
                for (int x = 0; x < iw; x++) {
                    int i = x * 4;
                    px[o + x] = 0xFF000000 | (row[i] & 255) << 16 | (row[i + 1] & 255) << 8 | (row[i + 2] & 255);
                }
            }
            wh[0] = iw;
            wh[1] = ih;
            return px;
        }
    }

    // ---------- auto-refresh (TIDAK menggerakkan apa pun, cuma menampilkan hint) ----------

    /** Harus dipanggil dari main thread. */
    private void toggleAuto() {
        if (autoOn) stopAuto(); else startAuto();
    }

    private void startAuto() {
        if (playOn) stopPlay();   // Main & Auto-hint tidak boleh jalan bareng (overlay hint merusak pembacaan papan)
        autoOn = true;
        forceReset = false;
        final int g = ++autoGen;
        autoBtn.setText("Auto: hidup");
        hintView.clear();   // buang sisa hint (mis. dari tombol Hint manual) supaya tidak ikut terbaca
        autoThread = new Thread(new Runnable() { public void run() { autoLoop(g); } });
        autoThread.start();
    }

    private void stopAuto() {
        autoOn = false;
        autoGen++;          // loop lama + semua post-nya jadi tidak berlaku
        forceReset = false;
        Thread t = autoThread;
        autoThread = null;
        if (t != null) t.interrupt();
        autoBtn.setText("Auto: mati");
        hintView.clear();   // hapus total semua hint (kotak di papan + angka di tray)
    }

    /** Jalankan r di main thread hanya kalau loop g masih yang aktif. */
    private void postIfCurrent(final int g, final Runnable r) {
        main.post(new Runnable() {
            public void run() { if (g == autoGen && autoOn) r.run(); }
        });
    }

    private static String signature(Detector.Result r) {
        StringBuilder sb = new StringBuilder(Arrays.toString(r.board));
        for (Detector.Slot s : r.slots)
            sb.append('|').append(s.piece == null ? "-" : s.piece.w + ":" + Arrays.toString(s.piece.rows));
        return sb.toString();
    }

    /**
     * Otomatis penuh, tanpa overlay yang dikedipkan:
     *  - Belum ada hint: baca layar tiap ~0,5 dtk. Begitu papan + 3 blok ketemu (stabil 2x) -> hint muncul.
     *  - Hint tampil: cuma pantau tray (overlay tidak menutupi tray) -> kotak blok yang sudah ditaruh hilang.
     *    Begitu 3 blok BARU muncul -> hint dihapus dan dihitung ulang otomatis.
     *  - Keluar dari game (papan hilang / tray kosong lama) -> hint dihapus sendiri.
     */
    private void autoLoop(final int g) {
        Detector.Result geo = null;
        boolean hinting = false, sawFewer = false;
        String candSig = null;
        int cand = 0, lost = 0, fresh = 0;
        long emptySince = 0;
        try {
            Thread.sleep(400);   // tunggu frame bersih (tanpa sisa overlay) sebelum mulai baca
            while (autoOn && g == autoGen) {
                if (forceReset) {
                    forceReset = false;
                    hinting = false; candSig = null; cand = 0;
                    postIfCurrent(g, new Runnable() { public void run() { hintView.clear(); } });
                    Thread.sleep(400);
                    continue;
                }
                int[] wh = new int[2];
                int[] px = grabPixels(wh);
                if (px == null) { Thread.sleep(500); continue; }
                int w = wh[0], h = wh[1];

                if (!hinting) {
                    Detector.Result r = Detector.detect(px, w, h);
                    int cnt = 0;
                    if (r.error == null) for (Detector.Slot s : r.slots) if (s != null && s.piece != null) cnt++;
                    if (r.error != null || cnt < 3) { candSig = null; cand = 0; Thread.sleep(600); continue; }

                    String sig = signature(r);
                    if (sig.equals(candSig)) cand++; else { candSig = sig; cand = 1; }
                    if (cand >= 2) {
                        final Analysis a = plan(r, new Analysis());
                        candSig = null; cand = 0;
                        if (a.error == null) {
                            geo = r.geometryOnly();
                            hinting = true; sawFewer = false; lost = 0; fresh = 0; emptySince = 0;
                            postIfCurrent(g, new Runnable() {
                                public void run() { hintView.show(a.res, a.plan, a.pieces, a.slotOf); }
                            });
                        }
                    }
                    Thread.sleep(500);
                } else {
                    Detector.Result t = geo.geometryOnly();
                    Detector.readTray(px, w, h, t);
                    final boolean[] present = new boolean[3];
                    int count = 0;
                    for (int i = 0; i < 3; i++) {
                        present[i] = t.slots[i] != null && t.slots[i].piece != null;
                        if (present[i]) count++;
                    }
                    boolean ring = Detector.gridOk(px, w, h, geo);
                    lost = ring ? 0 : lost + 1;

                    long now = System.currentTimeMillis();
                    if (count == 0) { if (emptySince == 0) emptySince = now; } else emptySince = 0;
                    boolean gone = lost >= 3 || (emptySince != 0 && now - emptySince > 3000);

                    if (count < 3) sawFewer = true;
                    fresh = (count == 3 && sawFewer) ? fresh + 1 : 0;

                    if (gone || fresh >= 2) {
                        hinting = false; candSig = null; cand = 0;
                        postIfCurrent(g, new Runnable() { public void run() { hintView.clear(); } });
                        Thread.sleep(400);   // beri waktu overlay hilang dari layar sebelum dibaca ulang
                        continue;
                    }
                    postIfCurrent(g, new Runnable() { public void run() { hintView.setPresent(present); } });
                    Thread.sleep(450);
                }
            }
        } catch (InterruptedException ignored) {
        } catch (RuntimeException e) {
            if (g == autoGen) toast("Auto berhenti: " + e.getClass().getSimpleName());
        } finally {
            // Hanya beres-beres kalau ini loop yang masih aktif. Loop lama (sudah dimatiin/diganti)
            // tidak boleh menimpa state loop baru.
            if (g == autoGen) {
                autoOn = false;
                main.post(new Runnable() {
                    public void run() {
                        if (hintView != null) hintView.clear();
                        if (autoBtn != null) autoBtn.setText("Auto: mati");
                    }
                });
            }
        }
    }

    // ---------- auto play (menyeret blok lewat AutoPlayService) ----------

    /** Harus dipanggil dari main thread. */
    private void togglePlay() {
        if (playOn) { stopPlay(); return; }
        if (AutoPlayService.instance == null) {
            toast("Aktifkan \"BB Hint Auto Play\" di Aksesibilitas dulu");
            try {
                Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception ignored) { }
            return;
        }
        if (autoOn) stopAuto();
        hintView.clear();   // overlay hint ikut tertangkap layar dan merusak pembacaan papan
        playOn = true;
        final int g = ++playGen;
        playBtn.setText("Main: hidup");
        playThread = new Thread(new Runnable() { public void run() { playLoop(g); } });
        playThread.start();
    }

    private void stopPlay() {
        playOn = false;
        playGen++;
        Thread t = playThread;
        playThread = null;
        if (t != null) t.interrupt();
        playBtn.setText("Main: mati");
    }

    private void stopPlayFromWorker(final int g, final String msg) {
        main.post(new Runnable() {
            public void run() {
                if (g != playGen) return;
                stopPlay();
                toast(msg);
            }
        });
    }

    /** Baca layar sampai dua bacaan berturut-turut sama (animasi selesai). Null kalau timeout / bukan layar game. */
    private Detector.Result readStable(int g, boolean needTray, long timeoutMs) throws InterruptedException {
        long end = System.currentTimeMillis() + timeoutMs;
        String last = null;
        while (playOn && g == playGen && System.currentTimeMillis() < end) {
            int[] wh = new int[2];
            int[] px = grabPixels(wh);
            if (px != null) {
                Detector.Result r = Detector.detect(px, wh[0], wh[1]);
                if (r.error == null) {
                    String sig = needTray ? signature(r) : Arrays.toString(r.board);
                    if (sig.equals(last)) return r;
                    last = sig;
                } else {
                    last = null;
                }
            }
            Thread.sleep(350);
        }
        return null;
    }

    /**
     * Satu langkah per putaran (closed-loop): baca papan+tray -> hitung rencana -> seret blok pertama dari rencana
     * -> baca papan lagi untuk tahu blok mendarat di mana -> belajar offset -> ulangi (rencana dihitung ulang
     * dari papan yang sebenarnya, jadi kalau meleset pun langkah berikutnya tetap benar).
     */
    private void playLoop(final int g) {
        try {
            Thread.sleep(600);   // beri waktu overlay hint hilang dari layar
            while (playOn && g == playGen) {
                AutoPlayService svc = AutoPlayService.instance;
                if (svc == null) { stopPlayFromWorker(g, "Izin aksesibilitas mati, Main dihentikan"); return; }

                Detector.Result r = readStable(g, true, 6000);
                if (r == null) { Thread.sleep(500); continue; }   // bukan layar game / masih animasi

                List<Piece> ps = new ArrayList<>();
                List<Integer> slotIdx = new ArrayList<>();
                for (int s = 0; s < 3; s++) {
                    if (r.slots[s] != null && r.slots[s].piece != null) { ps.add(r.slots[s].piece); slotIdx.add(s); }
                }
                if (ps.isEmpty()) { Thread.sleep(500); continue; }

                Piece[] arr = ps.toArray(new Piece[0]);
                Solver.Plan plan = Solver.solve(r.board, arr);
                if (plan.placed == 0 || plan.moves.isEmpty()) { Thread.sleep(1000); continue; }   // tidak ada yang muat

                Solver.Move m = plan.moves.get(0);
                Piece pc = arr[m.piece];
                Detector.Slot sl = r.slots[slotIdx.get(m.piece)];
                float[] off = calib.next(pc.h);
                float sx = sl.x + sl.w / 2f, sy = sl.y + sl.h / 2f;
                float tx = r.left + (m.c + pc.w / 2f + off[0]) * r.cell;
                float ty = r.top + (m.r + pc.h / 2f + off[1]) * r.cell;

                final int[] before = r.board.clone();
                boolean sent = svc.drag(sx, sy, tx, ty, sw, sh);
                Thread.sleep(900);   // animasi taruh blok / hapus garis

                Detector.Result after = readStable(g, false, 5000);
                if (after == null) continue;   // tidak terbaca (mis. layar game over) -> ulangi dari awal

                int[] land = Landing.find(before, pc, m.r, m.c, after.board);
                if (land != null) {
                    calib.onLanded(land[0], land[1]);
                    prefs.edit().putString("calib", calib.save()).apply();
                    if (land[0] != 0 || land[1] != 0) toast("Meleset " + land[0] + " baris, " + land[1] + " kolom. Menyesuaikan...");
                } else if (!sent || Arrays.equals(after.board, before)) {
                    calib.onFail();   // blok tidak menempel
                    if (calib.exhausted()) {
                        stopPlayFromWorker(g, "Blok tidak mau menempel. Cek izin aksesibilitas, lalu coba lagi");
                        return;
                    }
                }
                // else: papan berubah tapi tidak dikenali (animasi / salah baca) -> abaikan, rencana dihitung ulang
            }
        } catch (InterruptedException ignored) {
        } catch (RuntimeException e) {
            stopPlayFromWorker(g, "Main berhenti: " + e.getClass().getSimpleName());
        }
    }

    @Override public void onDestroy() {
        autoOn = false;
        playOn = false;
        if (playThread != null) playThread.interrupt();
        if (autoThread != null) autoThread.interrupt();
        try { if (hintView != null) wm.removeView(hintView); } catch (Exception ignored) { }
        try { if (panel != null) wm.removeView(panel); } catch (Exception ignored) { }
        synchronized (frameLock) {
            if (held != null) { held.close(); held = null; }
        }
        if (vdisplay != null) vdisplay.release();
        if (reader != null) reader.close();
        if (projection != null) projection.stop();
        if (workThread != null) workThread.quitSafely();
        super.onDestroy();
    }
}
