package com.bbhint;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

import hint.Detector;
import hint.Piece;
import hint.Solver;

/** Menggambar kotak saran di atas papan dan nomor urutan di dekat blok tray. */
public class HintView extends View {
    private static final int[] COLORS = {0xFFFFB300, 0xFF00B8D4, 0xFFE91E63};

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);

    private Detector.Result res;
    private Solver.Plan plan;
    private Piece[] pieces;
    private int[] slotOf;
    private final boolean[] present = {true, true, true};
    private boolean[] deferred = new boolean[0];

    public HintView(Context c) {
        super(c);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(4f);
        stroke.setColor(0xFFFFFFFF);
        txt.setColor(0xFFFFFFFF);
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setTypeface(Typeface.DEFAULT_BOLD);
    }

    public void show(Detector.Result r, Solver.Plan p, Piece[] ps, int[] slots) {
        res = r; plan = p; pieces = ps; slotOf = slots;
        present[0] = present[1] = present[2] = true;
        deferred = new boolean[p.moves.size()];
        // Langkah yang menimpa kotak yang sudah terisi (papan asli + langkah sebelumnya) berarti
        // dia baru berlaku SETELAH ada baris/kolom yang terhapus. Kalau digambar bareng, kotaknya
        // bentrok. Jadi baru digambar setelah langkah-langkah sebelumnya selesai ditaruh.
        int[] occ = r.board.clone();
        for (int i = 0; i < p.moves.size(); i++) {
            Solver.Move m = p.moves.get(i);
            Piece pc = ps[m.piece];
            for (int rr = 0; rr < pc.h; rr++) {
                int bits = pc.rows[rr] << m.c;
                if ((occ[m.r + rr] & bits) != 0) deferred[i] = true;
                occ[m.r + rr] |= bits;
            }
        }
        invalidate();
    }

    /** Blok yang sudah diambil dari tray (sudah ditaruh) tidak digambar lagi. */
    public void setPresent(boolean[] now) {
        boolean changed = false;
        for (int i = 0; i < 3; i++) if (present[i] != now[i]) { present[i] = now[i]; changed = true; }
        if (changed) invalidate();
    }

    public void clear() {
        res = null; plan = null;
        invalidate();
    }

    /** Langkah i digambar kalau blok-nya masih di tray, dan (kalau "tertunda") semua langkah sebelumnya sudah ditaruh. */
    private boolean visible(int i) {
        Solver.Move m = plan.moves.get(i);
        if (!present[slotOf[m.piece]]) return false;
        if (!deferred[i]) return true;
        for (int j = 0; j < i; j++)
            if (present[slotOf[plan.moves.get(j).piece]]) return false;
        return true;
    }

    @Override protected void onDraw(Canvas cv) {
        if (res == null || plan == null) return;
        float cell = res.cell;
        for (int i = 0; i < plan.moves.size(); i++) {
            Solver.Move m = plan.moves.get(i);
            if (!present[slotOf[m.piece]]) continue;
            Piece p = pieces[m.piece];
            int color = COLORS[i % COLORS.length];
            fill.setColor(color);

            // nomor di bawah tray (di luar area baca tray) supaya tidak terbaca sebagai blok
            Detector.Slot s = res.slots[slotOf[m.piece]];
            float bx = s.x + s.w / 2, by = res.top + 8 * cell + cell * 3.9f;
            fill.setAlpha(255);
            cv.drawCircle(bx, by, cell * 0.3f, fill);
            txt.setTextSize(cell * 0.4f);
            cv.drawText(String.valueOf(i + 1), bx, by + cell * 0.14f, txt);

            if (!visible(i)) continue;
            fill.setAlpha(110);
            for (int r = 0; r < p.h; r++)
                for (int c = 0; c < p.w; c++) {
                    if ((p.rows[r] >> c & 1) == 0) continue;
                    float x = res.left + (m.c + c) * cell, y = res.top + (m.r + r) * cell;
                    RectF rect = new RectF(x + 4, y + 4, x + cell - 4, y + cell - 4);
                    cv.drawRoundRect(rect, 10, 10, fill);
                    cv.drawRoundRect(rect, 10, 10, stroke);
                }
            txt.setTextSize(cell * 0.5f);
            float fx = res.left + (m.c + firstCol(p) + 0.5f) * cell;
            float fy = res.top + (m.r + 0.5f) * cell + cell * 0.18f;
            cv.drawText(String.valueOf(i + 1), fx, fy, txt);
        }
    }

    private static int firstCol(Piece p) {
        for (int c = 0; c < p.w; c++) if ((p.rows[0] >> c & 1) != 0) return c;
        return 0;
    }
}
